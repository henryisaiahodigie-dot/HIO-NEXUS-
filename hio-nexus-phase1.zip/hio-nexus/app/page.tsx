import Link from "next/link";
import { auth } from "@clerk/nextjs/server";
import { redirect } from "next/navigation";

export default function HomePage() {
  const { userId } = auth();
  if (userId) redirect("/dashboard");

  return (
    <main className="min-h-screen bg-[#0A0A0A] flex flex-col items-center justify-center px-6 text-center">
      {/* Background gradient */}
      <div
        className="fixed inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse 80% 50% at 50% -10%, hsl(43 65% 55% / 0.08) 0%, transparent 70%)",
        }}
      />

      <div className="relative z-10 max-w-3xl">
        {/* Logo */}
        <div className="mb-8 inline-flex items-center gap-2 text-xs tracking-[0.3em] text-[hsl(43_65%_55%)] uppercase font-medium">
          <span className="w-8 h-px bg-[hsl(43_65%_55%)]" />
          HIO Nexus
          <span className="w-8 h-px bg-[hsl(43_65%_55%)]" />
        </div>

        <h1
          className="text-5xl md:text-7xl font-light mb-6 leading-tight"
          style={{ fontFamily: "var(--font-cormorant)", fontWeight: 300 }}
        >
          Your story
          <br />
          <em className="text-[hsl(43_65%_55%)]">deserves a screen.</em>
        </h1>

        <p className="text-lg text-[hsl(0_0%_55%)] mb-4 max-w-xl mx-auto leading-relaxed font-light">
          From manuscript to movie. HIO Nexus is the AI film studio that takes your
          biography, novel, or life story and turns it into a coherent cinematic production.
        </p>

        <p className="text-sm text-[hsl(0_0%_35%)] mb-12 max-w-lg mx-auto">
          Not just clips — coherent cinematic storytelling.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link
            href="/sign-up"
            className="inline-flex items-center justify-center px-8 py-3.5 bg-[hsl(43_65%_55%)] text-[#0A0A0A] font-medium text-sm tracking-wide hover:bg-[hsl(43_65%_65%)] transition-colors"
          >
            Start Your Film Project
          </Link>
          <Link
            href="/sign-in"
            className="inline-flex items-center justify-center px-8 py-3.5 border border-[hsl(0_0%_16%)] text-[hsl(0_0%_75%)] text-sm tracking-wide hover:border-[hsl(43_65%_55%)] hover:text-[hsl(43_65%_55%)] transition-colors"
          >
            Sign In
          </Link>
        </div>

        {/* Feature bullets */}
        <div className="mt-20 grid grid-cols-1 sm:grid-cols-3 gap-8 text-left max-w-2xl mx-auto">
          {[
            {
              label: "Story Intelligence",
              desc: "Upload any manuscript, biography, or memoir. AI extracts characters, arc, and scenes.",
            },
            {
              label: "Full Production Pipeline",
              desc: "Adaptation → Screenplay → Characters → Scenes → Storyboard → Export.",
            },
            {
              label: "Cinematic Quality",
              desc: "Connected to the best video providers. Not clips — a coherent film.",
            },
          ].map((f) => (
            <div key={f.label} className="border-t border-[hsl(0_0%_16%)] pt-6">
              <div className="text-xs text-[hsl(43_65%_55%)] tracking-widest uppercase mb-2">
                {f.label}
              </div>
              <p className="text-sm text-[hsl(0_0%_50%)] leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </main>
  );
}
