import { getCurrentDbUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { formatRelativeDate } from "@/lib/utils";
import { PROJECT_STATUS_LABELS } from "@/types";
import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = { title: "Dashboard" };

export default async function DashboardPage() {
  const user = await getCurrentDbUser();

  const projects = await prisma.project.findMany({
    where: { userId: user.id },
    orderBy: { updatedAt: "desc" },
    include: {
      sourceDocument: { select: { wordCount: true } },
      adaptation: { select: { logline: true, genre: true } },
      _count: { select: { characters: true, scenes: true } },
    },
  });

  const totalCreditsUsed = await prisma.creditTransaction.aggregate({
    where: { userId: user.id, type: "DEBIT" },
    _sum: { amount: true },
  });

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1
            className="text-4xl font-light mb-1"
            style={{ fontFamily: "var(--font-cormorant)" }}
          >
            {user.name ? `Welcome, ${user.name.split(" ")[0]}` : "Your Studio"}
          </h1>
          <p className="text-sm text-[hsl(0_0%_45%)]">
            Build the pilot first. Scale to the full film.
          </p>
        </div>
        <Link
          href="/projects/new"
          className="inline-flex items-center gap-2 px-5 py-2.5 bg-[hsl(43_65%_55%)] text-[#0A0A0A] text-sm font-medium hover:bg-[hsl(43_65%_65%)] transition-colors"
        >
          + New Project
        </Link>
      </div>

      {/* Stats bar */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Plan", value: user.plan },
          { label: "Credits Remaining", value: user.credits },
          { label: "Projects", value: projects.length },
          {
            label: "Credits Used",
            value: Math.abs(totalCreditsUsed._sum.amount ?? 0),
          },
        ].map((stat) => (
          <div
            key={stat.label}
            className="bg-[hsl(0_0%_7%)] border border-[hsl(0_0%_16%)] p-4"
          >
            <div className="text-xs text-[hsl(0_0%_45%)] uppercase tracking-widest mb-1">
              {stat.label}
            </div>
            <div
              className="text-2xl font-light"
              style={{ fontFamily: "var(--font-cormorant)" }}
            >
              {stat.value}
            </div>
          </div>
        ))}
      </div>

      {/* Projects list */}
      <div>
        <h2 className="text-xs uppercase tracking-widest text-[hsl(0_0%_40%)] mb-4">
          Active Projects
        </h2>

        {projects.length === 0 ? (
          <div className="border border-dashed border-[hsl(0_0%_20%)] p-12 text-center">
            <p className="text-[hsl(0_0%_40%)] mb-4">No projects yet.</p>
            <Link
              href="/projects/new"
              className="text-sm text-[hsl(43_65%_55%)] hover:underline"
            >
              Start your first film project →
            </Link>
          </div>
        ) : (
          <div className="space-y-2">
            {projects.map((project) => (
              <Link
                key={project.id}
                href={`/projects/${project.id}`}
                className="flex items-center justify-between p-4 bg-[hsl(0_0%_7%)] border border-[hsl(0_0%_16%)] hover:border-[hsl(43_65%_55%/0.4)] transition-colors group"
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-3 mb-1">
                    <h3 className="text-sm font-medium text-white group-hover:text-[hsl(43_65%_65%)] transition-colors truncate">
                      {project.title}
                    </h3>
                    <span className="text-[10px] px-2 py-0.5 border border-[hsl(0_0%_20%)] text-[hsl(0_0%_50%)] shrink-0">
                      {PROJECT_STATUS_LABELS[project.status]}
                    </span>
                  </div>
                  {project.adaptation?.logline && (
                    <p className="text-xs text-[hsl(0_0%_40%)] truncate">
                      {project.adaptation.logline}
                    </p>
                  )}
                  <div className="flex items-center gap-4 mt-1.5 text-[10px] text-[hsl(0_0%_35%)]">
                    {project.adaptation?.genre && (
                      <span>{project.adaptation.genre}</span>
                    )}
                    <span>{project._count.characters} characters</span>
                    <span>{project._count.scenes} scenes</span>
                    {project.sourceDocument?.wordCount && (
                      <span>
                        {project.sourceDocument.wordCount.toLocaleString()} words
                      </span>
                    )}
                    <span>{formatRelativeDate(project.updatedAt)}</span>
                  </div>
                </div>
                <span className="text-[hsl(0_0%_30%)] group-hover:text-[hsl(43_65%_55%)] transition-colors ml-4 text-lg">
                  →
                </span>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
