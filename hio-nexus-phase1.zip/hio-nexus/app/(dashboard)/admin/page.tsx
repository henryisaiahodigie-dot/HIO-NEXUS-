import type { Metadata } from "next";
export const metadata: Metadata = { title: "Admin" };

export default function AdminPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-light" style={{ fontFamily: "var(--font-cormorant)" }}>
        Admin Diagnostics
      </h1>
      <div className="bg-[hsl(0_0%_7%)] border border-[hsl(0_0%_16%)] p-6 text-sm text-[hsl(0_0%_50%)]">
        <p className="text-[hsl(43_65%_55%)] text-xs uppercase tracking-widest mb-2">Phase 1 — API Ready</p>
        <p>Full diagnostics available via <code className="text-[hsl(43_65%_55%)]">GET /api/admin/health</code></p>
        <p className="mt-2 text-xs text-[hsl(0_0%_40%)]">Access gated by ADMIN_CLERK_IDS env var. Admin UI built in Phase 2.</p>
      </div>
    </div>
  );
}
