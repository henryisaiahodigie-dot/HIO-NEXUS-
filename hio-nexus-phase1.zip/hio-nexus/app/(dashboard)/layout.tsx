import { auth } from "@clerk/nextjs/server";
import { redirect } from "next/navigation";

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { userId } = auth();
  if (!userId) redirect("/sign-in");

  return (
    <div className="min-h-screen bg-[#0A0A0A] flex">
      {/* Sidebar placeholder — built in Phase 2 UI */}
      <aside className="w-60 shrink-0 border-r border-[hsl(0_0%_16%)] bg-[hsl(0_0%_5%)] hidden md:flex flex-col">
        <div className="px-6 py-5 border-b border-[hsl(0_0%_16%)]">
          <span className="text-xs tracking-[0.25em] text-[hsl(43_65%_55%)] uppercase font-medium">
            HIO Nexus
          </span>
        </div>
        <nav className="flex-1 px-3 py-4 space-y-1">
          {[
            { href: "/dashboard", label: "Dashboard" },
            { href: "/projects/new", label: "New Project" },
          ].map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="flex items-center px-3 py-2 text-sm text-[hsl(0_0%_60%)] hover:text-white hover:bg-[hsl(0_0%_10%)] rounded-sm transition-colors"
            >
              {item.label}
            </a>
          ))}
        </nav>
      </aside>

      {/* Main content */}
      <main className="flex-1 overflow-auto">
        <div className="max-w-6xl mx-auto px-6 py-8">{children}</div>
      </main>
    </div>
  );
}
