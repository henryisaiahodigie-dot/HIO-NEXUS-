import { notFound } from "next/navigation";
import { getCurrentDbUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { PROJECT_STATUS_LABELS, MOVIE_STYLE_LABELS, TARGET_LENGTH_LABELS } from "@/types";
import { formatDate } from "@/lib/utils";
import type { Metadata } from "next";
import Link from "next/link";

export async function generateMetadata({
  params,
}: {
  params: { id: string };
}): Promise<Metadata> {
  const project = await prisma.project.findUnique({
    where: { id: params.id },
    select: { title: true },
  });
  return { title: project?.title ?? "Project" };
}

const PIPELINE_STEPS = [
  { key: "adaptation", label: "Adaptation", href: "adaptation", desc: "Logline, synopsis, treatment, beat sheet" },
  { key: "characters", label: "Characters", href: "characters", desc: "Character bible with visual descriptions" },
  { key: "scenes", label: "Scenes", href: "scenes", desc: "Scene breakdown and planner" },
  { key: "storyboard", label: "Storyboard", href: "storyboard", desc: "Shot list and generation prompts" },
  { key: "pipeline", label: "Pipeline", href: "pipeline", desc: "Render jobs and provider status" },
  { key: "export", label: "Export", href: "export", desc: "Download packages and final output" },
];

export default async function ProjectHubPage({
  params,
}: {
  params: { id: string };
}) {
  const user = await getCurrentDbUser();

  const project = await prisma.project.findUnique({
    where: { id: params.id },
    include: {
      sourceDocument: { select: { wordCount: true, fileType: true } },
      rightsDeclaration: { select: { classification: true } },
      adaptation: { select: { logline: true, genre: true, emotionalArc: true } },
      _count: {
        select: { characters: true, scenes: true, renderJobs: true, exportPackages: true },
      },
    },
  });

  if (!project || project.userId !== user.id) notFound();

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="border-b border-[hsl(0_0%_16%)] pb-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <Link
              href="/dashboard"
              className="text-xs text-[hsl(0_0%_40%)] hover:text-[hsl(43_65%_55%)] mb-3 inline-block"
            >
              ← Dashboard
            </Link>
            <h1
              className="text-4xl font-light"
              style={{ fontFamily: "var(--font-cormorant)" }}
            >
              {project.title}
            </h1>
            {project.adaptation?.logline && (
              <p className="text-sm text-[hsl(0_0%_50%)] mt-2 max-w-2xl">
                {project.adaptation.logline}
              </p>
            )}
          </div>
          <span className="text-xs px-3 py-1.5 border border-[hsl(0_0%_20%)] text-[hsl(0_0%_55%)] shrink-0 mt-6">
            {PROJECT_STATUS_LABELS[project.status]}
          </span>
        </div>

        {/* Meta row */}
        <div className="flex flex-wrap items-center gap-6 mt-4 text-xs text-[hsl(0_0%_40%)]">
          {project.movieStyle && (
            <span>Style: {MOVIE_STYLE_LABELS[project.movieStyle]}</span>
          )}
          {project.targetLength && (
            <span>Length: {TARGET_LENGTH_LABELS[project.targetLength]}</span>
          )}
          {project.adaptation?.genre && (
            <span>Genre: {project.adaptation.genre}</span>
          )}
          {project.sourceDocument?.wordCount && (
            <span>{project.sourceDocument.wordCount.toLocaleString()} words</span>
          )}
          {project.rightsDeclaration?.classification && (
            <span>Rights: {project.rightsDeclaration.classification}</span>
          )}
          <span>Created {formatDate(project.createdAt)}</span>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: "Characters", value: project._count.characters },
          { label: "Scenes", value: project._count.scenes },
          { label: "Render Jobs", value: project._count.renderJobs },
          { label: "Exports", value: project._count.exportPackages },
        ].map((s) => (
          <div
            key={s.label}
            className="bg-[hsl(0_0%_7%)] border border-[hsl(0_0%_16%)] p-4"
          >
            <div className="text-xs text-[hsl(0_0%_40%)] uppercase tracking-widest mb-1">
              {s.label}
            </div>
            <div
              className="text-2xl font-light"
              style={{ fontFamily: "var(--font-cormorant)" }}
            >
              {s.value}
            </div>
          </div>
        ))}
      </div>

      {/* Pipeline steps */}
      <div>
        <h2 className="text-xs uppercase tracking-widest text-[hsl(0_0%_40%)] mb-4">
          Production Pipeline
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {PIPELINE_STEPS.map((step, i) => (
            <Link
              key={step.key}
              href={`/projects/${params.id}/${step.href}`}
              className="p-4 bg-[hsl(0_0%_7%)] border border-[hsl(0_0%_16%)] hover:border-[hsl(43_65%_55%/0.5)] transition-colors group"
            >
              <div className="flex items-start justify-between mb-2">
                <span className="text-[10px] text-[hsl(43_65%_55%)] uppercase tracking-widest">
                  Step {i + 1}
                </span>
                <span className="text-[hsl(0_0%_30%)] group-hover:text-[hsl(43_65%_55%)] transition-colors">
                  →
                </span>
              </div>
              <div className="text-sm font-medium text-white mb-1">{step.label}</div>
              <div className="text-xs text-[hsl(0_0%_40%)]">{step.desc}</div>
            </Link>
          ))}
        </div>
      </div>

      {/* Analyze CTA (if not yet analyzed) */}
      {project.status === "DRAFT" && (
        <div className="border border-[hsl(43_65%_55%/0.3)] bg-[hsl(43_65%_55%/0.05)] p-6">
          <p className="text-sm text-[hsl(0_0%_70%)] mb-3">
            <strong className="text-[hsl(43_65%_55%)]">Ready to begin?</strong> Run
            story analysis to extract your film's characters, scenes, and emotional arc.
            Costs 1 credit.
          </p>
          <p className="text-xs text-[hsl(0_0%_40%)]">
            Use{" "}
            <code className="text-[hsl(43_65%_55%)]">
              POST /api/projects/{params.id}/analyze
            </code>{" "}
            to start. Full UI controls in Phase 2.
          </p>
        </div>
      )}
    </div>
  );
}
