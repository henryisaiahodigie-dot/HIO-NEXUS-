import type { Metadata } from "next";
export const metadata: Metadata = { title: "Adaptation" };

export default function AdaptationPage({ params }: { params: { id: string } }) {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-light" style={{ fontFamily: "var(--font-cormorant)" }}>
        Adaptation Engine
      </h1>
      <p className="text-sm text-[hsl(0_0%_45%)]">
        Logline · Synopsis · Treatment · Beat Sheet · Act Structure
      </p>
      <div className="bg-[hsl(0_0%_7%)] border border-[hsl(0_0%_16%)] p-6 text-sm text-[hsl(0_0%_50%)]">
        <p className="text-[hsl(43_65%_55%)] text-xs uppercase tracking-widest mb-2">Phase 1 — API Ready</p>
        <p>Backend fully wired. UI components built in Phase 2.</p>
        <ul className="mt-3 space-y-1 text-xs text-[hsl(0_0%_40%)]">
          <li><code>POST /api/projects/{params.id}/analyze</code> — Run story analysis (1 credit)</li>
          <li><code>POST /api/projects/{params.id}/adaptation</code> — Generate full adaptation (1 credit)</li>
          <li><code>PATCH /api/projects/{params.id}/adaptation</code> — Manual edits</li>
          <li><code>GET /api/projects/{params.id}/adaptation</code> — Fetch current adaptation</li>
        </ul>
      </div>
    </div>
  );
}
