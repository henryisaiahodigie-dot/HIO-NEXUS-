import type { Metadata } from "next";
export const metadata: Metadata = { title: "Project" };

export default function SubPage({ params }: { params: { id: string } }) {
  return (
    <div className="space-y-6">
      <div className="bg-[hsl(0_0%_7%)] border border-[hsl(0_0%_16%)] p-6 text-sm text-[hsl(0_0%_50%)]">
        <p className="text-[hsl(43_65%_55%)] text-xs uppercase tracking-widest mb-2">Phase 1 — API Ready</p>
        <p>Backend fully wired. Interactive UI built in Phase 2.</p>
        <p className="mt-2 text-xs text-[hsl(0_0%_40%)]">Project ID: {params.id}</p>
      </div>
    </div>
  );
}
