import type { Metadata } from "next";

export const metadata: Metadata = { title: "New Project" };

// Phase 1: This page houses the new-project-form component.
// Full form built in Phase 2 UI sprint. Foundation wired to actions.
export default function NewProjectPage() {
  return (
    <div className="max-w-2xl space-y-8">
      <div>
        <h1
          className="text-4xl font-light mb-2"
          style={{ fontFamily: "var(--font-cormorant)" }}
        >
          New Film Project
        </h1>
        <p className="text-sm text-[hsl(0_0%_45%)]">
          Upload your story and begin the production pipeline.
        </p>
      </div>

      <div className="bg-[hsl(0_0%_7%)] border border-[hsl(0_0%_16%)] p-6 space-y-4">
        <p className="text-xs text-[hsl(43_65%_55%)] uppercase tracking-widest">
          Phase 1 Foundation
        </p>
        <p className="text-sm text-[hsl(0_0%_60%)]">
          Backend API and Server Actions are fully wired. The interactive form
          component is built in the Phase 2 UI sprint. Use the API directly at{" "}
          <code className="text-[hsl(43_65%_55%)]">POST /api/projects</code> to
          create a project with your story text.
        </p>
        <div className="text-xs text-[hsl(0_0%_40%)] space-y-1">
          <div>Required fields: title, rawText (min 100 chars)</div>
          <div>Optional: movieStyle, targetLength, mode (SIMPLE|STUDIO)</div>
        </div>
      </div>
    </div>
  );
}
