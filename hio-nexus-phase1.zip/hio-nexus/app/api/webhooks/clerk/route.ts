import { NextRequest, NextResponse } from "next/server";
import { Webhook } from "svix";
import { prisma } from "@/lib/prisma";

type ClerkUserData = {
  id: string;
  email_addresses: Array<{ email_address: string; id: string }>;
  primary_email_address_id: string;
  first_name: string | null;
  last_name: string | null;
  image_url: string | null;
};

export async function POST(req: NextRequest) {
  const webhookSecret = process.env.CLERK_WEBHOOK_SECRET;
  if (!webhookSecret) {
    return NextResponse.json(
      { error: "CLERK_WEBHOOK_SECRET is not configured" },
      { status: 500 }
    );
  }

  const svixId = req.headers.get("svix-id");
  const svixTimestamp = req.headers.get("svix-timestamp");
  const svixSignature = req.headers.get("svix-signature");

  if (!svixId || !svixTimestamp || !svixSignature) {
    return NextResponse.json({ error: "Missing svix headers" }, { status: 400 });
  }

  const body = await req.text();

  let event: { type: string; data: ClerkUserData };
  try {
    const wh = new Webhook(webhookSecret);
    event = wh.verify(body, {
      "svix-id": svixId,
      "svix-timestamp": svixTimestamp,
      "svix-signature": svixSignature,
    }) as { type: string; data: ClerkUserData };
  } catch {
    return NextResponse.json({ error: "Invalid webhook signature" }, { status: 400 });
  }

  const { type, data } = event;

  try {
    switch (type) {
      case "user.created": {
        const primaryEmail =
          data.email_addresses.find((e) => e.id === data.primary_email_address_id)
            ?.email_address ?? "";

        await prisma.user.upsert({
          where: { clerkId: data.id },
          update: {},
          create: {
            clerkId: data.id,
            email: primaryEmail,
            name:
              [data.first_name, data.last_name].filter(Boolean).join(" ") || null,
            imageUrl: data.image_url,
          },
        });
        break;
      }

      case "user.updated": {
        const primaryEmail =
          data.email_addresses.find((e) => e.id === data.primary_email_address_id)
            ?.email_address ?? "";

        await prisma.user.updateMany({
          where: { clerkId: data.id },
          data: {
            email: primaryEmail,
            name:
              [data.first_name, data.last_name].filter(Boolean).join(" ") || null,
            imageUrl: data.image_url,
          },
        });
        break;
      }

      case "user.deleted": {
        // Cascade deletes all projects + data via Prisma cascade rules
        await prisma.user.deleteMany({ where: { clerkId: data.id } });
        break;
      }

      default:
        break;
    }

    return NextResponse.json({ received: true });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
