import { NextRequest, NextResponse } from "next/server";
import { requireProjectOwner, deductCredits } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { generateStoryboardPrompts } from "@/lib/ai";

export async function GET(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await requireProjectOwner(params.id);
    const frames = await prisma.storyboardFrame.findMany({
      where: { scene: { projectId: params.id } },
      include: { scene: { select: { sceneNumber: true, title: true } }, shot: true },
      orderBy: [{ scene: { sceneNumber: "asc" } }, { frameNumber: "asc" }],
    });
    return NextResponse.json({ frames });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

/**
 * POST { generate: true } — Generate storyboard shots + prompts for all scenes.
 * POST { sceneId } — Generate storyboard for a single scene.
 */
export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireProjectOwner(params.id);
    const body = await req.json();

    const project = await prisma.project.findUnique({
      where: { id: params.id },
      include: {
        scenes: { orderBy: { sceneNumber: "asc" } },
        adaptation: { select: { visualStyleGuide: true } },
      },
    });

    if (!project?.scenes.length) {
      return NextResponse.json(
        { error: "Generate scenes first before creating storyboard." },
        { status: 400 }
      );
    }

    const scenesToProcess = body.sceneId
      ? project.scenes.filter((s) => s.id === body.sceneId)
      : project.scenes;

    if (!scenesToProcess.length) {
      return NextResponse.json({ error: "Scene not found." }, { status: 404 });
    }

    await deductCredits(user.id, 1, "Storyboard generation", params.id);

    const visualStyleGuide = project.adaptation?.visualStyleGuide ?? "";
    const allShots = [];

    for (const scene of scenesToProcess) {
      // Generate shot prompts for this scene
      const shots = await generateStoryboardPrompts(
        scene,
        visualStyleGuide,
        project.movieStyle ?? "CINEMATIC_DRAMA"
      );

      // Delete existing shots for this scene and replace
      await prisma.shot.deleteMany({ where: { sceneId: scene.id } });

      type GeneratedShot = {
        shotNumber: number;
        description?: string;
        cameraMovement?: string;
        framing?: string;
        lighting?: string;
        composition?: string;
        transition?: string;
        generationPrompt?: string;
        continuityRef?: string;
        estimatedSeconds?: number;
      };

      for (const shot of shots as GeneratedShot[]) {
        const createdShot = await prisma.shot.create({
          data: {
            sceneId: scene.id,
            shotNumber: shot.shotNumber,
            description: shot.description ?? null,
            cameraMovement: shot.cameraMovement ?? null,
            framing: shot.framing ?? null,
            lighting: shot.lighting ?? null,
            composition: shot.composition ?? null,
            transition: shot.transition ?? null,
            generationPrompt: shot.generationPrompt ?? null,
            continuityRef: shot.continuityRef ?? null,
            estimatedSeconds: shot.estimatedSeconds ?? null,
            status: "PENDING",
          },
        });

        // Create storyboard frame for each shot
        await prisma.storyboardFrame.create({
          data: {
            sceneId: scene.id,
            shotId: createdShot.id,
            frameNumber: shot.shotNumber,
            imagePrompt: shot.generationPrompt ?? null,
            caption: shot.description ?? null,
          },
        });

        allShots.push(createdShot);
      }
    }

    await prisma.renderJob.create({
      data: {
        projectId: params.id,
        jobType: "STORYBOARD_GENERATION",
        status: "COMPLETED",
        progress: 100,
        creditsUsed: 1,
        completedAt: new Date(),
      },
    });

    return NextResponse.json({ shots: allShots }, { status: 201 });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    if (message === "Insufficient credits") {
      return NextResponse.json({ error: message }, { status: 402 });
    }
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
