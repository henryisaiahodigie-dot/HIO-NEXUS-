import { NextRequest, NextResponse } from "next/server";
import { requireProjectOwner, deductCredits } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { updateSceneSchema } from "@/lib/validations";
import { generateScenes } from "@/lib/ai";

export async function GET(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await requireProjectOwner(params.id);
    const scenes = await prisma.scene.findMany({
      where: { projectId: params.id },
      orderBy: { sceneNumber: "asc" },
      include: {
        shots: { orderBy: { shotNumber: "asc" } },
        storyboardFrames: { orderBy: { frameNumber: "asc" } },
      },
    });
    return NextResponse.json({ scenes });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireProjectOwner(params.id);
    const body = await req.json();

    // AI generation path
    if (body.generate === true) {
      const project = await prisma.project.findUnique({
        where: { id: params.id },
        include: {
          adaptation: true,
          characters: { select: { name: true, role: true } },
        },
      });

      if (!project?.adaptation) {
        return NextResponse.json(
          { error: "Run adaptation generation first." },
          { status: 400 }
        );
      }

      await deductCredits(user.id, 1, "Scene generation", params.id);

      await prisma.project.update({
        where: { id: params.id },
        data: { status: "STORYBOARDING" },
      });

      const generatedScenes = await generateScenes(
        project.adaptation as Record<string, unknown>,
        project.characters,
        project.movieStyle ?? "CINEMATIC_DRAMA",
        project.targetLength ?? "PILOT_10MIN"
      );

      // Replace existing scenes
      await prisma.scene.deleteMany({ where: { projectId: params.id } });

      type GeneratedScene = {
        sceneNumber: number;
        title?: string;
        location?: string;
        timeOfDay?: string;
        actionSummary?: string;
        dialogue?: string;
        narration?: string;
        cameraDirection?: string;
        mood?: string;
        musicCue?: string;
        vfxRequirements?: string;
        continuityNotes?: string;
        estimatedDuration?: number;
      };

      const scenes = await prisma.$transaction(
        generatedScenes.map((scene: GeneratedScene) =>
          prisma.scene.create({
            data: {
              projectId: params.id,
              sceneNumber: scene.sceneNumber,
              title: scene.title ?? null,
              location: scene.location ?? null,
              timeOfDay: scene.timeOfDay ?? null,
              actionSummary: scene.actionSummary ?? null,
              dialogue: scene.dialogue ?? null,
              narration: scene.narration ?? null,
              cameraDirection: scene.cameraDirection ?? null,
              mood: scene.mood ?? null,
              musicCue: scene.musicCue ?? null,
              vfxRequirements: scene.vfxRequirements ?? null,
              continuityNotes: scene.continuityNotes ?? null,
              estimatedDuration: scene.estimatedDuration ?? null,
              status: "DRAFT",
            },
          })
        )
      );

      await prisma.renderJob.create({
        data: {
          projectId: params.id,
          jobType: "SCENE_GENERATION",
          status: "COMPLETED",
          progress: 100,
          creditsUsed: 1,
          completedAt: new Date(),
        },
      });

      return NextResponse.json({ scenes }, { status: 201 });
    }

    // Manual creation path
    const validated = updateSceneSchema.parse(body);
    const lastScene = await prisma.scene.findFirst({
      where: { projectId: params.id },
      orderBy: { sceneNumber: "desc" },
    });
    const nextNumber = (lastScene?.sceneNumber ?? 0) + 1;

    const scene = await prisma.scene.create({
      data: { projectId: params.id, sceneNumber: nextNumber, ...validated },
    });

    return NextResponse.json({ scene }, { status: 201 });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    if (message === "Insufficient credits") {
      return NextResponse.json({ error: message }, { status: 402 });
    }
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
