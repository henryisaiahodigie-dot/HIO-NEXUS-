import { NextRequest, NextResponse } from "next/server";
import { requireProjectOwner, deductCredits } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { analyzeStory } from "@/lib/ai";

export async function POST(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireProjectOwner(params.id);

    const project = await prisma.project.findUnique({
      where: { id: params.id },
      include: { sourceDocument: true },
    });

    if (!project?.sourceDocument) {
      return NextResponse.json(
        { error: "No source document found. Please create a project with story text first." },
        { status: 400 }
      );
    }

    // Deduct 1 credit for story analysis
    await deductCredits(user.id, 1, "Story analysis", params.id);

    // Update project status to ANALYZING
    await prisma.project.update({
      where: { id: params.id },
      data: { status: "ANALYZING" },
    });

    // Run AI analysis
    const analysisResult = await analyzeStory(
      project.sourceDocument.rawText,
      project.title
    );

    // Upsert adaptation record with extracted data
    const adaptation = await prisma.adaptation.upsert({
      where: { projectId: params.id },
      update: {
        logline: analysisResult.logline ?? null,
        synopsis: analysisResult.synopsis ?? null,
        genre: analysisResult.genre ?? null,
        timeline: analysisResult.timeline ?? null,
        locations: analysisResult.locations ?? [],
        themes: analysisResult.themes ?? [],
        mainCharacters: analysisResult.mainCharacters ?? [],
        emotionalArc: analysisResult.emotionalArc ?? null,
        majorEvents: analysisResult.majorEvents ?? [],
        conflicts: analysisResult.conflicts ?? [],
        sensitiveContent: analysisResult.sensitiveContent ?? null,
        adaptationRisk: analysisResult.adaptationRisk ?? null,
      },
      create: {
        projectId: params.id,
        logline: analysisResult.logline ?? null,
        synopsis: analysisResult.synopsis ?? null,
        genre: analysisResult.genre ?? null,
        timeline: analysisResult.timeline ?? null,
        locations: analysisResult.locations ?? [],
        themes: analysisResult.themes ?? [],
        mainCharacters: analysisResult.mainCharacters ?? [],
        emotionalArc: analysisResult.emotionalArc ?? null,
        majorEvents: analysisResult.majorEvents ?? [],
        conflicts: analysisResult.conflicts ?? [],
        sensitiveContent: analysisResult.sensitiveContent ?? null,
        adaptationRisk: analysisResult.adaptationRisk ?? null,
      },
    });

    // Update suggested movie style if not already set
    if (!project.movieStyle && analysisResult.suggestedMovieStyle) {
      await prisma.project.update({
        where: { id: params.id },
        data: {
          movieStyle: analysisResult.suggestedMovieStyle,
          status: "SCRIPTING",
        },
      });
    } else {
      await prisma.project.update({
        where: { id: params.id },
        data: { status: "SCRIPTING" },
      });
    }

    // Log render job for audit trail
    await prisma.renderJob.create({
      data: {
        projectId: params.id,
        jobType: "STORY_ANALYSIS",
        status: "COMPLETED",
        progress: 100,
        creditsUsed: 1,
        completedAt: new Date(),
      },
    });

    return NextResponse.json({ adaptation, analysisResult });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";

    // Revert project status on failure
    await prisma.project.update({
      where: { id: params.id },
      data: { status: "FAILED" },
    }).catch(() => null);

    if (message === "Insufficient credits") {
      return NextResponse.json(
        { error: "Insufficient credits. Purchase more credits to continue." },
        { status: 402 }
      );
    }
    if (message === "Unauthorized" || message.startsWith("Forbidden")) {
      return NextResponse.json({ error: message }, { status: 403 });
    }
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
