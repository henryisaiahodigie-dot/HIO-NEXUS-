import { NextRequest, NextResponse } from "next/server";
import { requireProjectOwner, deductCredits } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { updateAdaptationSchema } from "@/lib/validations";
import { generateAdaptation } from "@/lib/ai";

export async function GET(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await requireProjectOwner(params.id);
    const adaptation = await prisma.adaptation.findUnique({
      where: { projectId: params.id },
    });
    return NextResponse.json({ adaptation });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

/**
 * POST — Generate full adaptation using AI (treatment, beat sheet, act structure, etc.)
 * Requires story analysis to have been run first.
 */
export async function POST(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireProjectOwner(params.id);

    const project = await prisma.project.findUnique({
      where: { id: params.id },
      include: {
        sourceDocument: true,
        adaptation: true,
      },
    });

    if (!project?.sourceDocument) {
      return NextResponse.json(
        { error: "No source document found." },
        { status: 400 }
      );
    }

    if (!project.adaptation) {
      return NextResponse.json(
        { error: "Run story analysis first before generating adaptation." },
        { status: 400 }
      );
    }

    await deductCredits(user.id, 1, "Adaptation generation", params.id);

    const result = await generateAdaptation(
      project.sourceDocument.rawText,
      project.adaptation as Record<string, unknown>,
      project.movieStyle ?? "CINEMATIC_DRAMA",
      project.targetLength ?? "PILOT_10MIN",
      project.adaptation.adaptationType ?? "FAITHFUL"
    );

    const adaptation = await prisma.adaptation.update({
      where: { projectId: params.id },
      data: {
        treatment: result.treatment ?? null,
        beatSheet: result.beatSheet ?? null,
        actStructure: result.actStructure ?? null,
        narrationPlan: result.narrationPlan ?? null,
        dialoguePlan: result.dialoguePlan ?? null,
        visualStyleGuide: result.visualStyleGuide ?? null,
        emotionalToneGuide: result.emotionalToneGuide ?? null,
      },
    });

    await prisma.renderJob.create({
      data: {
        projectId: params.id,
        jobType: "ADAPTATION",
        status: "COMPLETED",
        progress: 100,
        creditsUsed: 1,
        completedAt: new Date(),
      },
    });

    return NextResponse.json({ adaptation });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    if (message === "Insufficient credits") {
      return NextResponse.json({ error: message }, { status: 402 });
    }
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

/**
 * PATCH — Manual edits to adaptation fields (Studio Mode).
 */
export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await requireProjectOwner(params.id);
    const body = await req.json();
    const validated = updateAdaptationSchema.parse(body);

    const adaptation = await prisma.adaptation.upsert({
      where: { projectId: params.id },
      update: validated,
      create: { projectId: params.id, ...validated },
    });

    return NextResponse.json({ adaptation });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
