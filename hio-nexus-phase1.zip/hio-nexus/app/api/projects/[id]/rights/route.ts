import { NextRequest, NextResponse } from "next/server";
import { requireProjectOwner } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { rightsDeclarationSchema } from "@/lib/validations";
import { classifyRights } from "@/lib/auth";

export async function GET(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await requireProjectOwner(params.id);
    const rights = await prisma.rightsDeclaration.findUnique({
      where: { projectId: params.id },
    });
    return NextResponse.json({ rights });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await requireProjectOwner(params.id);
    const body = await req.json();
    const validated = rightsDeclarationSchema.parse(body);
    const classification = classifyRights(validated);

    if (classification === "BLOCKED") {
      return NextResponse.json(
        {
          error:
            "This project has been flagged as high-risk and cannot proceed. " +
            "It involves real people with sensitive claims and you do not own the story. " +
            "Please consult a legal professional before proceeding.",
          classification,
        },
        { status: 422 }
      );
    }

    const rights = await prisma.rightsDeclaration.upsert({
      where: { projectId: params.id },
      update: { ...validated, classification },
      create: { projectId: params.id, ...validated, classification },
    });

    // If risky, set project status to NEEDS_USER_INPUT
    if (classification === "RISKY" || classification === "NEEDS_REVIEW") {
      await prisma.project.update({
        where: { id: params.id },
        data: { status: "NEEDS_USER_INPUT" },
      });
    }

    return NextResponse.json({ rights });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    if (error && typeof error === "object" && "issues" in error) {
      return NextResponse.json({ error: "Validation failed", details: error }, { status: 400 });
    }
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
