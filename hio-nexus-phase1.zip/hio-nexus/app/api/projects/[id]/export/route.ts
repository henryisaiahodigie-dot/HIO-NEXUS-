import { NextRequest, NextResponse } from "next/server";
import { requireProjectOwner, deductCredits } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { z } from "zod";

const exportRequestSchema = z.object({
  exportType: z.enum([
    "ADAPTATION_REPORT",
    "SCREENPLAY_PDF",
    "STORYBOARD_PDF",
    "CHARACTER_BIBLE_PDF",
    "PRODUCTION_PACKAGE_ZIP",
    "TRAILER",
    "PILOT_PREVIEW",
    "MP4_ANIMATIC",
    "FULL_MOVIE",
    "SOCIAL_CLIPS",
    "SUBTITLES",
    "AUDIO_ONLY",
  ]),
});

const RENDER_REQUIRED_TYPES = new Set([
  "TRAILER",
  "PILOT_PREVIEW",
  "MP4_ANIMATIC",
  "FULL_MOVIE",
  "SOCIAL_CLIPS",
  "AUDIO_ONLY",
]);

export async function GET(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await requireProjectOwner(params.id);
    const packages = await prisma.exportPackage.findMany({
      where: { projectId: params.id },
      orderBy: { createdAt: "desc" },
    });
    return NextResponse.json({ packages });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireProjectOwner(params.id);
    const body = await req.json();
    const { exportType } = exportRequestSchema.parse(body);

    // Render-required exports need a connected provider
    if (RENDER_REQUIRED_TYPES.has(exportType)) {
      const hasProvider =
        !!process.env.KLING_API_KEY ||
        !!process.env.RUNWAY_API_KEY ||
        !!process.env.VEO_API_KEY;

      if (!hasProvider) {
        return NextResponse.json(
          {
            error:
              "Final cinematic rendering requires a connected render provider. " +
              "Configure KLING_API_KEY, RUNWAY_API_KEY, or VEO_API_KEY to enable video rendering.",
            requiresRenderProvider: true,
          },
          { status: 422 }
        );
      }
    }

    await deductCredits(user.id, 1, `Export: ${exportType}`, params.id);

    // Create export job record
    const exportPackage = await prisma.exportPackage.create({
      data: {
        projectId: params.id,
        exportType,
        status: "PENDING",
        metadata: { requestedAt: new Date().toISOString() },
      },
    });

    // Create render job for tracking
    await prisma.renderJob.create({
      data: {
        projectId: params.id,
        jobType: "EXPORT_PACKAGE",
        status: "QUEUED",
        progress: 0,
        creditsUsed: 1,
        metadata: { exportPackageId: exportPackage.id, exportType },
      },
    });

    await prisma.project.update({
      where: { id: params.id },
      data: { status: "EXPORTING" },
    });

    // Phase 1: For document exports, mark as complete with placeholder URL.
    // Phase 2: Queue actual document/video generation via background worker.
    const isDocumentExport = [
      "ADAPTATION_REPORT",
      "SCREENPLAY_PDF",
      "STORYBOARD_PDF",
      "CHARACTER_BIBLE_PDF",
      "PRODUCTION_PACKAGE_ZIP",
    ].includes(exportType);

    if (isDocumentExport) {
      await prisma.exportPackage.update({
        where: { id: exportPackage.id },
        data: {
          status: "PENDING",
          metadata: {
            requestedAt: new Date().toISOString(),
            note: "Document generation queued. Phase 2 worker will process this.",
          },
        },
      });
    }

    return NextResponse.json({ exportPackage }, { status: 201 });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    if (message === "Insufficient credits") {
      return NextResponse.json({ error: message }, { status: 402 });
    }
    if (error && typeof error === "object" && "issues" in error) {
      return NextResponse.json({ error: "Validation failed" }, { status: 400 });
    }
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
