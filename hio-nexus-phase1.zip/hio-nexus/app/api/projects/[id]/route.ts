import { NextRequest, NextResponse } from "next/server";
import { requireProjectOwner } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { z } from "zod";

const updateProjectSchema = z.object({
  title: z.string().min(2).max(200).optional(),
  description: z.string().max(1000).optional(),
  movieStyle: z
    .enum([
      "DOCUMENTARY",
      "CINEMATIC_DRAMA",
      "HISTORICAL_EPIC",
      "FAITH_INSPIRATIONAL",
      "ROMANCE",
      "ACTION",
      "ANIMATION",
      "CHILDREN_FAMILY",
      "THRILLER",
    ])
    .optional(),
  targetLength: z
    .enum(["TRAILER", "SHORT_3MIN", "PILOT_10MIN", "EPISODE_30MIN", "FEATURE_FILM"])
    .optional(),
});

export async function GET(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await requireProjectOwner(params.id);

    const project = await prisma.project.findUnique({
      where: { id: params.id },
      include: {
        sourceDocument: true,
        rightsDeclaration: true,
        adaptation: true,
        characters: { orderBy: { orderIndex: "asc" } },
        scenes: {
          orderBy: { sceneNumber: "asc" },
          include: {
            shots: { orderBy: { shotNumber: "asc" } },
            storyboardFrames: { orderBy: { frameNumber: "asc" } },
          },
        },
        renderJobs: { orderBy: { createdAt: "desc" }, take: 10 },
        exportPackages: { orderBy: { createdAt: "desc" } },
        _count: { select: { characters: true, scenes: true, renderJobs: true } },
      },
    });

    if (!project) {
      return NextResponse.json({ error: "Project not found" }, { status: 404 });
    }

    return NextResponse.json({ project });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    if (message === "Unauthorized" || message.startsWith("Forbidden")) {
      return NextResponse.json({ error: message }, { status: 403 });
    }
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await requireProjectOwner(params.id);
    const body = await req.json();
    const validated = updateProjectSchema.parse(body);

    const project = await prisma.project.update({
      where: { id: params.id },
      data: validated,
    });

    return NextResponse.json({ project });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    if (message === "Unauthorized" || message.startsWith("Forbidden")) {
      return NextResponse.json({ error: message }, { status: 403 });
    }
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await requireProjectOwner(params.id);

    await prisma.project.delete({ where: { id: params.id } });

    return NextResponse.json({ success: true });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    if (message === "Unauthorized" || message.startsWith("Forbidden")) {
      return NextResponse.json({ error: message }, { status: 403 });
    }
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
