import { NextRequest, NextResponse } from "next/server";
import { requireProjectOwner, deductCredits } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { updateCharacterSchema } from "@/lib/validations";
import { generateCharacters } from "@/lib/ai";

export async function GET(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await requireProjectOwner(params.id);
    const characters = await prisma.character.findMany({
      where: { projectId: params.id },
      orderBy: { orderIndex: "asc" },
    });
    return NextResponse.json({ characters });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

/**
 * POST with { generate: true } — AI generation of character bible.
 * POST with character data — Manual character creation.
 */
export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await requireProjectOwner(params.id);
    const body = await req.json();

    // AI generation path
    if (body.generate === true) {
      const project = await prisma.project.findUnique({
        where: { id: params.id },
        include: { sourceDocument: true, adaptation: true },
      });

      if (!project?.sourceDocument || !project.adaptation) {
        return NextResponse.json(
          { error: "Run story analysis and adaptation first." },
          { status: 400 }
        );
      }

      await deductCredits(user.id, 1, "Character bible generation", params.id);

      const generatedChars = await generateCharacters(
        project.sourceDocument.rawText,
        project.adaptation as Record<string, unknown>
      );

      // Delete existing AI-generated characters and replace
      await prisma.character.deleteMany({ where: { projectId: params.id } });

      const characters = await prisma.$transaction(
        generatedChars.map(
          (
            char: {
              name: string;
              age?: string;
              role?: string;
              biography?: string;
              personality?: string;
              motivation?: string;
              relationships?: string;
              visualDescription?: string;
              wardrobe?: string;
              voiceStyle?: string;
              emotionalArc?: string;
              continuityNotes?: string;
            },
            idx: number
          ) =>
            prisma.character.create({
              data: {
                projectId: params.id,
                name: char.name,
                age: char.age ?? null,
                role:
                  (char.role as
                    | "PROTAGONIST"
                    | "ANTAGONIST"
                    | "SUPPORTING"
                    | "NARRATOR"
                    | "MINOR") ?? "SUPPORTING",
                biography: char.biography ?? null,
                personality: char.personality ?? null,
                motivation: char.motivation ?? null,
                relationships: char.relationships ?? null,
                visualDescription: char.visualDescription ?? null,
                wardrobe: char.wardrobe ?? null,
                voiceStyle: char.voiceStyle ?? null,
                emotionalArc: char.emotionalArc ?? null,
                continuityNotes: char.continuityNotes ?? null,
                orderIndex: idx,
              },
            })
        )
      );

      await prisma.renderJob.create({
        data: {
          projectId: params.id,
          jobType: "CHARACTER_GENERATION",
          status: "COMPLETED",
          progress: 100,
          creditsUsed: 1,
          completedAt: new Date(),
        },
      });

      return NextResponse.json({ characters }, { status: 201 });
    }

    // Manual creation path
    const validated = updateCharacterSchema.parse(body);
    const count = await prisma.character.count({ where: { projectId: params.id } });

    const character = await prisma.character.create({
      data: { projectId: params.id, ...validated, orderIndex: count },
    });

    return NextResponse.json({ character }, { status: 201 });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    if (message === "Insufficient credits") {
      return NextResponse.json({ error: message }, { status: 402 });
    }
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
