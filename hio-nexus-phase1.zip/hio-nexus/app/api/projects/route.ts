import { NextResponse } from "next/server";
import { NextRequest } from "next/server";
import { getCurrentDbUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { createProjectSchema } from "@/lib/validations";
import { PLAN_MAX_PROJECTS } from "@/types";
import { wordCount } from "@/lib/utils";

export async function GET() {
  try {
    const user = await getCurrentDbUser();
    const projects = await prisma.project.findMany({
      where: { userId: user.id },
      include: {
        sourceDocument: { select: { wordCount: true, fileType: true } },
        adaptation: { select: { logline: true, genre: true } },
        _count: { select: { characters: true, scenes: true } },
      },
      orderBy: { updatedAt: "desc" },
    });
    return NextResponse.json({ projects });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    if (message === "Unauthorized") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await getCurrentDbUser();
    const body = await req.json();
    const validated = createProjectSchema.parse(body);

    // Enforce project limit per plan
    const projectCount = await prisma.project.count({
      where: { userId: user.id },
    });
    const maxProjects = PLAN_MAX_PROJECTS[user.plan];
    if (projectCount >= maxProjects) {
      return NextResponse.json(
        {
          error: `Your ${user.plan} plan allows up to ${maxProjects} project(s). Upgrade to create more.`,
        },
        { status: 403 }
      );
    }

    const project = await prisma.project.create({
      data: {
        userId: user.id,
        title: validated.title,
        description: validated.description ?? null,
        mode: validated.mode,
        movieStyle: validated.movieStyle ?? null,
        targetLength: validated.targetLength ?? null,
        status: "DRAFT",
        sourceDocument: {
          create: {
            rawText: validated.rawText,
            fileType: validated.fileType,
            wordCount: wordCount(validated.rawText),
          },
        },
      },
      include: { sourceDocument: true },
    });

    return NextResponse.json({ project }, { status: 201 });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    if (message === "Unauthorized") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    // Zod error
    if (error && typeof error === "object" && "issues" in error) {
      return NextResponse.json({ error: "Validation failed", details: error }, { status: 400 });
    }
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
