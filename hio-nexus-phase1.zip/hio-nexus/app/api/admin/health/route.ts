import { NextResponse } from "next/server";
import { auth } from "@clerk/nextjs/server";
import { isAdminUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getProviderReadiness } from "@/lib/provider-abstraction";

export async function GET() {
  try {
    const { userId } = auth();
    if (!userId || !isAdminUser(userId)) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    // DB health
    const [
      userCount,
      projectCount,
      renderJobCounts,
      failedJobs,
      exportCount,
    ] = await Promise.all([
      prisma.user.count(),
      prisma.project.count(),
      prisma.renderJob.groupBy({
        by: ["status"],
        _count: { id: true },
      }),
      prisma.renderJob.findMany({
        where: { status: "FAILED" },
        orderBy: { updatedAt: "desc" },
        take: 10,
        select: {
          id: true,
          jobType: true,
          errorMessage: true,
          updatedAt: true,
          project: { select: { title: true } },
        },
      }),
      prisma.exportPackage.count(),
    ]);

    const projectStatusCounts = await prisma.project.groupBy({
      by: ["status"],
      _count: { id: true },
    });

    const recentActivity = await prisma.renderJob.findMany({
      orderBy: { createdAt: "desc" },
      take: 20,
      select: {
        id: true,
        jobType: true,
        status: true,
        progress: true,
        creditsUsed: true,
        createdAt: true,
        completedAt: true,
        project: { select: { id: true, title: true } },
      },
    });

    const providers = getProviderReadiness();

    return NextResponse.json({
      health: "ok",
      timestamp: new Date().toISOString(),
      database: {
        status: "connected",
        users: userCount,
        projects: projectCount,
        exports: exportCount,
        projectStatusBreakdown: projectStatusCounts,
        renderJobBreakdown: renderJobCounts,
      },
      renderProviders: providers,
      failedJobs,
      recentActivity,
      environment: {
        anthropicConfigured: !!process.env.ANTHROPIC_API_KEY,
        supabaseConfigured:
          !!process.env.NEXT_PUBLIC_SUPABASE_URL &&
          !!process.env.SUPABASE_SERVICE_ROLE_KEY,
        clerkConfigured: !!process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY,
      },
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json(
      { health: "error", error: message },
      { status: 500 }
    );
  }
}
