import { NextResponse } from "next/server";
import { getCurrentDbUser } from "@/lib/auth";

export async function GET() {
  try {
    const user = await getCurrentDbUser();
    return NextResponse.json({ user });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    if (message === "Unauthorized") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
