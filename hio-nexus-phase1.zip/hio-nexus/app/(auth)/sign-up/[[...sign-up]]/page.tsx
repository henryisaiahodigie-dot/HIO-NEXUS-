import { SignUp } from "@clerk/nextjs";

export default function SignUpPage() {
  return (
    <div className="min-h-screen bg-[#0A0A0A] flex items-center justify-center">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <p className="text-xs tracking-[0.3em] text-[hsl(43_65%_55%)] uppercase mb-3">
            HIO Nexus
          </p>
          <h1
            className="text-3xl font-light"
            style={{ fontFamily: "var(--font-cormorant)" }}
          >
            Start your film project
          </h1>
          <p className="text-sm text-[hsl(0_0%_50%)] mt-2">
            3 free credits to begin. No card required.
          </p>
        </div>
        <SignUp
          appearance={{
            elements: {
              rootBox: "w-full",
              card: "bg-[hsl(0_0%_7%)] border border-[hsl(0_0%_16%)] shadow-xl rounded-none",
              headerTitle: "hidden",
              headerSubtitle: "hidden",
              socialButtonsBlockButton:
                "border border-[hsl(0_0%_16%)] bg-transparent hover:bg-[hsl(0_0%_11%)] text-white",
              formFieldInput:
                "bg-[hsl(0_0%_11%)] border-[hsl(0_0%_20%)] text-white focus:border-[hsl(43_65%_55%)]",
              formButtonPrimary:
                "bg-[hsl(43_65%_55%)] hover:bg-[hsl(43_65%_65%)] text-[#0A0A0A] font-medium",
              footerActionLink: "text-[hsl(43_65%_55%)] hover:text-[hsl(43_65%_70%)]",
            },
          }}
        />
      </div>
    </div>
  );
}
