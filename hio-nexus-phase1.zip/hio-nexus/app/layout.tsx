import type { Metadata } from "next";
import { ClerkProvider } from "@clerk/nextjs";
import { Toaster } from "sonner";
import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: "HIO Nexus — AI Film Studio",
    template: "%s | HIO Nexus",
  },
  description:
    "Turn your manuscript, biography, or life story into a cinematic film. HIO Nexus is the AI-powered film production studio in your browser.",
  keywords: [
    "AI film studio",
    "manuscript to movie",
    "AI screenplay",
    "cinematic AI",
    "story to film",
    "biography film",
  ],
  authors: [{ name: "HIO Nexus" }],
  creator: "HIO Nexus",
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://hionexus.com",
    title: "HIO Nexus — AI Film Studio",
    description: "Your story deserves a screen. From manuscript to movie.",
    siteName: "HIO Nexus",
  },
  twitter: {
    card: "summary_large_image",
    title: "HIO Nexus — AI Film Studio",
    description: "Your story deserves a screen. From manuscript to movie.",
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <ClerkProvider>
      <html lang="en" className="dark">
        <body>
          {children}
          <Toaster
            theme="dark"
            position="bottom-right"
            toastOptions={{
              style: {
                background: "hsl(0 0% 9%)",
                border: "1px solid hsl(0 0% 16%)",
                color: "hsl(0 0% 95%)",
              },
            }}
          />
        </body>
      </html>
    </ClerkProvider>
  );
}
