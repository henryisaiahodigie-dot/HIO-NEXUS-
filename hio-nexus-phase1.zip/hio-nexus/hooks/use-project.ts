"use client";

import { useEffect, useState } from "react";
import type { ProjectWithRelations } from "@/types";

interface UseProjectResult {
  project: ProjectWithRelations | null;
  isLoading: boolean;
  error: string | null;
  refetch: () => void;
}

export function useProject(projectId: string): UseProjectResult {
  const [project, setProject] = useState<ProjectWithRelations | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [tick, setTick] = useState(0);

  useEffect(() => {
    if (!projectId) return;

    let cancelled = false;

    async function fetchProject() {
      setIsLoading(true);
      setError(null);
      try {
        const res = await fetch(`/api/projects/${projectId}`);
        if (!res.ok) {
          const data = await res.json().catch(() => ({}));
          throw new Error(data.error ?? `HTTP ${res.status}`);
        }
        const data = await res.json();
        if (!cancelled) setProject(data.project);
      } catch (err) {
        if (!cancelled) {
          setError(err instanceof Error ? err.message : "Failed to load project");
        }
      } finally {
        if (!cancelled) setIsLoading(false);
      }
    }

    fetchProject();
    return () => { cancelled = true; };
  }, [projectId, tick]);

  return {
    project,
    isLoading,
    error,
    refetch: () => setTick((t) => t + 1),
  };
}
