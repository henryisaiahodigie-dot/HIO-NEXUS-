"use client";

import { useEffect, useState } from "react";
import type { Project } from "@prisma/client";

interface ProjectListItem extends Project {
  sourceDocument: { wordCount: number | null; fileType: string } | null;
  adaptation: { logline: string | null; genre: string | null } | null;
  _count: { characters: number; scenes: number };
}

interface UseProjectsResult {
  projects: ProjectListItem[];
  isLoading: boolean;
  error: string | null;
  refetch: () => void;
}

export function useProjects(): UseProjectsResult {
  const [projects, setProjects] = useState<ProjectListItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [tick, setTick] = useState(0);

  useEffect(() => {
    let cancelled = false;

    async function fetchProjects() {
      setIsLoading(true);
      setError(null);
      try {
        const res = await fetch("/api/projects");
        if (!res.ok) {
          const data = await res.json().catch(() => ({}));
          throw new Error(data.error ?? `HTTP ${res.status}`);
        }
        const data = await res.json();
        if (!cancelled) setProjects(data.projects);
      } catch (err) {
        if (!cancelled) {
          setError(err instanceof Error ? err.message : "Failed to load projects");
        }
      } finally {
        if (!cancelled) setIsLoading(false);
      }
    }

    fetchProjects();
    return () => { cancelled = true; };
  }, [tick]);

  return {
    projects,
    isLoading,
    error,
    refetch: () => setTick((t) => t + 1),
  };
}
