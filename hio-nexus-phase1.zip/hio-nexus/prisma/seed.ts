import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  console.log("Seeding subscription plans...");

  // Upsert all four subscription plans from the PDF spec
  const plans = [
    {
      name: "Free",
      plan: "FREE" as const,
      price: 0,
      creditsPerMonth: 3,
      maxProjects: 1,
      features: [
        "1 project",
        "Story analysis",
        "3 credits/month",
        "Adaptation report",
        "Character bible (preview)",
      ],
    },
    {
      name: "Creator",
      plan: "CREATOR" as const,
      price: 29,
      creditsPerMonth: 50,
      maxProjects: 10,
      features: [
        "10 projects",
        "50 credits/month",
        "Full adaptation pipeline",
        "Screenplay PDF export",
        "Storyboard PDF export",
        "Character bible export",
        "MP4 animatic proof cut",
        "Production package ZIP",
      ],
    },
    {
      name: "Studio",
      plan: "STUDIO" as const,
      price: 99,
      creditsPerMonth: 200,
      maxProjects: 50,
      features: [
        "50 projects",
        "200 credits/month",
        "All Creator features",
        "Higher-quality render providers",
        "Team collaboration",
        "Advanced timeline editor",
        "Commercial license tools",
        "Priority rendering",
      ],
    },
    {
      name: "Enterprise",
      plan: "ENTERPRISE" as const,
      price: 499,
      creditsPerMonth: 1000,
      maxProjects: 999,
      features: [
        "Unlimited projects",
        "1000 credits/month",
        "All Studio features",
        "Private model/provider setup",
        "Custom render pipelines",
        "White-label deployment",
        "Priority rendering",
        "Dedicated support",
        "Publisher/studio accounts",
        "Revenue share support",
      ],
    },
  ];

  for (const plan of plans) {
    await prisma.subscriptionPlan.upsert({
      where: { name: plan.name },
      update: plan,
      create: plan,
    });
    console.log(`  ✓ ${plan.name} plan`);
  }

  console.log("\nSeed complete.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
