import type {
  User,
  Project,
  SourceDocument,
  RightsDeclaration,
  Adaptation,
  Character,
  Scene,
  Shot,
  StoryboardFrame,
  RenderJob,
  ExportPackage,
  ReviewComment,
  Plan,
  ProjectStatus,
  MovieStyle,
  TargetLength,
  ProjectMode,
  RightsStatus,
  AdaptationType,
  CharacterRole,
  SceneStatus,
  RenderStatus,
  RenderJobType,
  ExportType,
} from "@prisma/client";

export type {
  User,
  Project,
  SourceDocument,
  RightsDeclaration,
  Adaptation,
  Character,
  Scene,
  Shot,
  StoryboardFrame,
  RenderJob,
  ExportPackage,
  ReviewComment,
  Plan,
  ProjectStatus,
  MovieStyle,
  TargetLength,
  ProjectMode,
  RightsStatus,
  AdaptationType,
  CharacterRole,
  SceneStatus,
  RenderStatus,
  RenderJobType,
  ExportType,
};

export type ProjectWithRelations = Project & {
  sourceDocument?: SourceDocument | null;
  rightsDeclaration?: RightsDeclaration | null;
  adaptation?: Adaptation | null;
  characters?: Character[];
  scenes?: Scene[];
  renderJobs?: RenderJob[];
  exportPackages?: ExportPackage[];
};

export type SceneWithRelations = Scene & {
  shots?: Shot[];
  storyboardFrames?: StoryboardFrame[];
  characters?: Character[];
};

export const MOVIE_STYLE_LABELS: Record<MovieStyle, string> = {
  DOCUMENTARY: "Documentary",
  CINEMATIC_DRAMA: "Cinematic Drama",
  HISTORICAL_EPIC: "Historical Epic",
  FAITH_INSPIRATIONAL: "Faith / Inspirational",
  ROMANCE: "Romance",
  ACTION: "Action",
  ANIMATION: "Animation",
  CHILDREN_FAMILY: "Children / Family",
  THRILLER: "Thriller",
};

export const TARGET_LENGTH_LABELS: Record<TargetLength, string> = {
  TRAILER: "Trailer (~2 min)",
  SHORT_3MIN: "Short Film (3 min)",
  PILOT_10MIN: "Pilot Episode (10 min)",
  EPISODE_30MIN: "Full Episode (30 min)",
  FEATURE_FILM: "Feature Film (Roadmap)",
};

export const PROJECT_STATUS_LABELS: Record<ProjectStatus, string> = {
  DRAFT: "Draft",
  ANALYZING: "Analyzing Story",
  SCRIPTING: "Writing Script",
  STORYBOARDING: "Creating Storyboard",
  RENDERING: "Rendering",
  REVIEWING: "Under Review",
  EXPORTING: "Exporting",
  COMPLETED: "Completed",
  FAILED: "Failed",
  NEEDS_USER_INPUT: "Needs Your Input",
};

export const ADAPTATION_TYPE_LABELS: Record<AdaptationType, string> = {
  FAITHFUL: "Faithful Adaptation",
  DRAMATIZED: "Dramatized Version",
  DOCUMENTARY: "Documentary Style",
  FICTIONALIZED: "Fictionalized Version",
  CHILDREN_FAMILY: "Children / Family Version",
  TRAILER_ONLY: "Trailer Only",
  EPISODIC_SERIES: "Episodic Series",
};

export const PLAN_LABELS: Record<Plan, string> = {
  FREE: "Free",
  CREATOR: "Creator",
  STUDIO: "Studio",
  ENTERPRISE: "Enterprise",
};

export const PLAN_CREDITS: Record<Plan, number> = {
  FREE: 3,
  CREATOR: 50,
  STUDIO: 200,
  ENTERPRISE: 1000,
};

export const PLAN_MAX_PROJECTS: Record<Plan, number> = {
  FREE: 1,
  CREATOR: 10,
  STUDIO: 50,
  ENTERPRISE: 999,
};
