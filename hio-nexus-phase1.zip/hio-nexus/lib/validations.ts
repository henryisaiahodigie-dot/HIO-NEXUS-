import { z } from "zod";

export const createProjectSchema = z.object({
  title: z.string().min(2, "Title must be at least 2 characters").max(200),
  description: z.string().max(1000).optional(),
  mode: z.enum(["SIMPLE", "STUDIO"]).default("SIMPLE"),
  movieStyle: z
    .enum([
      "DOCUMENTARY",
      "CINEMATIC_DRAMA",
      "HISTORICAL_EPIC",
      "FAITH_INSPIRATIONAL",
      "ROMANCE",
      "ACTION",
      "ANIMATION",
      "CHILDREN_FAMILY",
      "THRILLER",
    ])
    .optional(),
  targetLength: z
    .enum(["TRAILER", "SHORT_3MIN", "PILOT_10MIN", "EPISODE_30MIN", "FEATURE_FILM"])
    .optional(),
  rawText: z.string().min(100, "Story must be at least 100 characters").max(200000),
  fileType: z.enum(["PDF", "DOCX", "TXT", "TEXT"]).default("TEXT"),
});

export const rightsDeclarationSchema = z.object({
  ownsStory: z.boolean(),
  isPublicDomain: z.boolean(),
  hasAdaptationRights: z.boolean(),
  involvesRealPeople: z.boolean(),
  hasSensitiveClaims: z.boolean(),
  shouldAnonymize: z.boolean(),
  additionalNotes: z.string().max(2000).optional(),
});

export const updateAdaptationSchema = z.object({
  logline: z.string().max(500).optional(),
  synopsis: z.string().max(5000).optional(),
  treatment: z.string().max(20000).optional(),
  beatSheet: z.string().max(10000).optional(),
  actStructure: z.string().max(10000).optional(),
  narrationPlan: z.string().max(5000).optional(),
  dialoguePlan: z.string().max(5000).optional(),
  visualStyleGuide: z.string().max(5000).optional(),
  emotionalToneGuide: z.string().max(5000).optional(),
  adaptationType: z
    .enum([
      "FAITHFUL",
      "DRAMATIZED",
      "DOCUMENTARY",
      "FICTIONALIZED",
      "CHILDREN_FAMILY",
      "TRAILER_ONLY",
      "EPISODIC_SERIES",
    ])
    .optional(),
});

export const updateCharacterSchema = z.object({
  name: z.string().min(1).max(200),
  age: z.string().max(50).optional(),
  role: z.enum(["PROTAGONIST", "ANTAGONIST", "SUPPORTING", "NARRATOR", "MINOR"]),
  biography: z.string().max(5000).optional(),
  personality: z.string().max(2000).optional(),
  motivation: z.string().max(1000).optional(),
  relationships: z.string().max(3000).optional(),
  visualDescription: z.string().max(2000).optional(),
  wardrobe: z.string().max(1000).optional(),
  voiceStyle: z.string().max(1000).optional(),
  emotionalArc: z.string().max(2000).optional(),
  continuityNotes: z.string().max(2000).optional(),
});

export const updateSceneSchema = z.object({
  title: z.string().max(200).optional(),
  location: z.string().max(500).optional(),
  timeOfDay: z.string().max(50).optional(),
  actionSummary: z.string().max(5000).optional(),
  dialogue: z.string().max(10000).optional(),
  narration: z.string().max(5000).optional(),
  cameraDirection: z.string().max(1000).optional(),
  mood: z.string().max(200).optional(),
  musicCue: z.string().max(500).optional(),
  vfxRequirements: z.string().max(1000).optional(),
  continuityNotes: z.string().max(2000).optional(),
  estimatedDuration: z.number().int().min(0).max(3600).optional(),
});

export type CreateProjectInput = z.infer<typeof createProjectSchema>;
export type RightsDeclarationInput = z.infer<typeof rightsDeclarationSchema>;
export type UpdateAdaptationInput = z.infer<typeof updateAdaptationSchema>;
export type UpdateCharacterInput = z.infer<typeof updateCharacterSchema>;
export type UpdateSceneInput = z.infer<typeof updateSceneSchema>;
