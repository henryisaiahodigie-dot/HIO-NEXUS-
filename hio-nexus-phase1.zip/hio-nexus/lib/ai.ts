import Anthropic from "@anthropic-ai/sdk";

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY!,
});

export async function analyzeStory(rawText: string, projectTitle: string) {
  const message = await anthropic.messages.create({
    model: "claude-opus-4-5",
    max_tokens: 4096,
    messages: [
      {
        role: "user",
        content: `You are a professional story analyst and screenwriter. Analyze the following story/manuscript for cinematic adaptation potential.

Story Title: ${projectTitle}

Story Content:
${rawText.substring(0, 8000)}

Respond ONLY with a valid JSON object (no markdown, no preamble) with this exact structure:
{
  "genre": "string",
  "timeline": "string describing time period and span",
  "locations": ["location1", "location2"],
  "mainCharacters": ["character1", "character2"],
  "emotionalArc": "string describing the emotional journey",
  "majorEvents": ["event1", "event2", "event3"],
  "conflicts": ["conflict1", "conflict2"],
  "themes": ["theme1", "theme2"],
  "sensitiveContent": "string or null",
  "adaptationRisk": "LOW | MEDIUM | HIGH with brief explanation",
  "logline": "one-sentence story summary for film",
  "synopsis": "3-5 sentence film synopsis",
  "adaptationPotential": "string describing cinematic potential",
  "suggestedMovieStyle": "DOCUMENTARY | CINEMATIC_DRAMA | HISTORICAL_EPIC | FAITH_INSPIRATIONAL | ROMANCE | ACTION | ANIMATION | CHILDREN_FAMILY | THRILLER",
  "estimatedRuntime": "string like '90-120 minutes'"
}`,
      },
    ],
  });

  const text = message.content[0].type === "text" ? message.content[0].text : "";
  return JSON.parse(text);
}

export async function generateAdaptation(
  rawText: string,
  analysisData: Record<string, unknown>,
  movieStyle: string,
  targetLength: string,
  adaptationType: string
) {
  const message = await anthropic.messages.create({
    model: "claude-opus-4-5",
    max_tokens: 8192,
    messages: [
      {
        role: "user",
        content: `You are a professional Hollywood screenwriter. Create a complete cinematic adaptation document.

Story Analysis:
${JSON.stringify(analysisData, null, 2)}

Original Story (excerpt):
${rawText.substring(0, 6000)}

Movie Style: ${movieStyle}
Target Length: ${targetLength}
Adaptation Type: ${adaptationType}

Respond ONLY with a valid JSON object with this structure:
{
  "logline": "one compelling sentence",
  "synopsis": "full paragraph synopsis",
  "treatment": "detailed 3-5 paragraph treatment describing the film",
  "beatSheet": "numbered list of major story beats",
  "actStructure": "Act 1 setup, Act 2 confrontation, Act 3 resolution breakdown",
  "narrationPlan": "description of narration style and approach",
  "dialoguePlan": "description of dialogue style and key scenes requiring dialogue",
  "visualStyleGuide": "cinematography style, color palette, visual references",
  "emotionalToneGuide": "emotional journey and tonal guidance for each act"
}`,
      },
    ],
  });

  const text = message.content[0].type === "text" ? message.content[0].text : "";
  return JSON.parse(text);
}

export async function generateCharacters(
  rawText: string,
  analysisData: Record<string, unknown>
) {
  const message = await anthropic.messages.create({
    model: "claude-opus-4-5",
    max_tokens: 6144,
    messages: [
      {
        role: "user",
        content: `You are a professional character developer for film. Create detailed character bibles.

Story Analysis:
${JSON.stringify(analysisData, null, 2)}

Story Excerpt:
${rawText.substring(0, 4000)}

Respond ONLY with a valid JSON array of character objects:
[
  {
    "name": "character name",
    "age": "age or age range",
    "role": "PROTAGONIST | ANTAGONIST | SUPPORTING | NARRATOR | MINOR",
    "biography": "detailed background story",
    "personality": "personality traits and quirks",
    "motivation": "what drives this character",
    "relationships": "key relationships with other characters",
    "visualDescription": "detailed physical appearance for casting/generation",
    "wardrobe": "typical clothing style and key outfit notes",
    "voiceStyle": "speech patterns, accent, tone",
    "emotionalArc": "how this character changes through the story",
    "continuityNotes": "important notes for visual consistency across scenes"
  }
]

Generate between 3 and 8 characters. Include all major characters.`,
      },
    ],
  });

  const text = message.content[0].type === "text" ? message.content[0].text : "";
  return JSON.parse(text);
}

export async function generateScenes(
  adaptationData: Record<string, unknown>,
  characters: Array<{ name: string; role: string }>,
  movieStyle: string,
  targetLength: string
) {
  const sceneCount = getSceneCount(targetLength);

  const message = await anthropic.messages.create({
    model: "claude-opus-4-5",
    max_tokens: 8192,
    messages: [
      {
        role: "user",
        content: `You are a professional film director and script supervisor. Break down this story into cinematic scenes.

Adaptation Data:
${JSON.stringify(adaptationData, null, 2)}

Characters:
${JSON.stringify(characters, null, 2)}

Movie Style: ${movieStyle}
Target Length: ${targetLength}
Target Scene Count: approximately ${sceneCount} scenes

Respond ONLY with a valid JSON array of scene objects:
[
  {
    "sceneNumber": 1,
    "title": "Scene title",
    "location": "INT. LOCATION - TIME or EXT. LOCATION - TIME",
    "timeOfDay": "DAWN | MORNING | DAY | AFTERNOON | DUSK | NIGHT",
    "actionSummary": "2-3 sentences describing what happens",
    "dialogue": "key dialogue lines or 'No dialogue - visual scene'",
    "narration": "narrator text if any",
    "cameraDirection": "key camera directions (WIDE SHOT, CLOSE UP, etc.)",
    "mood": "emotional tone of the scene",
    "musicCue": "music style/feel for this scene",
    "vfxRequirements": "any special effects needed or 'None'",
    "continuityNotes": "important continuity information",
    "estimatedDuration": 90,
    "charactersPresent": ["Character Name 1", "Character Name 2"]
  }
]`,
      },
    ],
  });

  const text = message.content[0].type === "text" ? message.content[0].text : "";
  return JSON.parse(text);
}

export async function generateStoryboardPrompts(
  scene: {
    sceneNumber: number;
    title?: string | null;
    location?: string | null;
    actionSummary?: string | null;
    cameraDirection?: string | null;
    mood?: string | null;
  },
  visualStyleGuide: string,
  movieStyle: string
) {
  const message = await anthropic.messages.create({
    model: "claude-opus-4-5",
    max_tokens: 2048,
    messages: [
      {
        role: "user",
        content: `You are a professional storyboard artist and cinematographer. Create detailed shot descriptions for this scene.

Scene:
${JSON.stringify(scene, null, 2)}

Visual Style Guide: ${visualStyleGuide}
Movie Style: ${movieStyle}

Respond ONLY with a valid JSON array of shots (2-4 shots per scene):
[
  {
    "shotNumber": 1,
    "description": "Detailed shot description",
    "cameraMovement": "STATIC | PAN | TILT | DOLLY | TRACKING | HANDHELD | CRANE",
    "framing": "EXTREME WIDE | WIDE | MEDIUM WIDE | MEDIUM | MEDIUM CLOSE | CLOSE UP | EXTREME CLOSE UP",
    "lighting": "Natural soft light | Hard dramatic shadows | etc.",
    "composition": "Rule of thirds | Central composition | etc.",
    "transition": "CUT | DISSOLVE | FADE | WIPE | MATCH CUT",
    "generationPrompt": "Highly detailed AI image/video generation prompt for this exact shot, cinematic, [style] cinematography, [mood] lighting, [camera] shot of [action/subject], photorealistic, 8k",
    "continuityRef": "Key visual elements to maintain across shots",
    "estimatedSeconds": 5
  }
]`,
      },
    ],
  });

  const text = message.content[0].type === "text" ? message.content[0].text : "";
  return JSON.parse(text);
}

function getSceneCount(targetLength: string): number {
  switch (targetLength) {
    case "TRAILER": return 5;
    case "SHORT_3MIN": return 8;
    case "PILOT_10MIN": return 12;
    case "EPISODE_30MIN": return 20;
    case "FEATURE_FILM": return 30;
    default: return 12;
  }
}
