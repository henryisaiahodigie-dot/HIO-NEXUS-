/**
 * Video Provider Abstraction Layer
 *
 * This is the Phase 1 stub implementation. Real providers are wired in Phase 2.
 * The interface matches the spec in both PDFs exactly.
 */

export interface ShotGenerationInput {
  prompt: string;
  style: string;
  duration: number;
  resolution?: string;
  characterReference?: string;
  styleReference?: string;
  negativePrompt?: string;
  metadata?: Record<string, unknown>;
}

export interface GeneratedShot {
  jobId: string;
  provider: string;
  status: "QUEUED" | "PROCESSING" | "COMPLETED" | "FAILED";
  estimatedSeconds?: number;
}

export interface RenderStatusResult {
  jobId: string;
  status: "QUEUED" | "PROCESSING" | "COMPLETED" | "FAILED";
  progress: number;
  errorMessage?: string;
}

export interface VideoAsset {
  jobId: string;
  url: string;
  duration: number;
  resolution: string;
  provider: string;
}

export interface VideoProvider {
  name: string;
  generateShot(input: ShotGenerationInput): Promise<GeneratedShot>;
  checkStatus(jobId: string): Promise<RenderStatusResult>;
  getResult(jobId: string): Promise<VideoAsset>;
}

// ─── Provider registry ────────────────────────────────────────────────────────

class StubProvider implements VideoProvider {
  name: string;

  constructor(name: string) {
    this.name = name;
  }

  async generateShot(_input: ShotGenerationInput): Promise<GeneratedShot> {
    return {
      jobId: `stub-${this.name}-${Date.now()}`,
      provider: this.name,
      status: "QUEUED",
      estimatedSeconds: 60,
    };
  }

  async checkStatus(jobId: string): Promise<RenderStatusResult> {
    return { jobId, status: "QUEUED", progress: 0 };
  }

  async getResult(jobId: string): Promise<VideoAsset> {
    throw new Error(
      `Provider ${this.name} is not yet configured. ` +
        `Final cinematic rendering requires a connected render provider.`
    );
  }
}

// Stub implementations for all providers from the PDF spec
// Replace with real API clients in Phase 2
export const providers: Record<string, VideoProvider> = {
  kling: new StubProvider("kling"),
  runway: new StubProvider("runway"),
  veo: new StubProvider("veo"),
  ltx: new StubProvider("ltx"),
  pika: new StubProvider("pika"),
  stable_video: new StubProvider("stable_video"),
};

// ─── Provider selection logic ─────────────────────────────────────────────────

export type ProviderPriority = "quality" | "cost" | "speed";

export interface ProviderSelectionOptions {
  priority?: ProviderPriority;
  userPlan?: string;
  duration?: number;
  style?: string;
}

/**
 * Selects the best available provider based on priority and user tier.
 * Phase 1: always returns stub. Phase 2: real selection logic.
 */
export function selectProvider(options: ProviderSelectionOptions): VideoProvider {
  const { priority = "quality", userPlan = "FREE" } = options;

  // Phase 2: real routing by quality/cost/speed + plan tier
  // Phase 1: stub provider only
  const providerName = "kling"; // default preferred provider
  return providers[providerName] ?? providers["kling"];
}

/**
 * Returns the readiness status of all providers.
 */
export function getProviderReadiness(): Record<
  string,
  { configured: boolean; message: string }
> {
  const configured: Record<string, boolean> = {
    kling: !!process.env.KLING_API_KEY,
    runway: !!process.env.RUNWAY_API_KEY,
    veo: !!process.env.VEO_API_KEY,
    ltx: !!process.env.LTX_API_KEY,
    pika: !!process.env.PIKA_API_KEY,
    elevenlabs: !!process.env.ELEVENLABS_API_KEY,
  };

  return Object.fromEntries(
    Object.entries(configured).map(([name, isConfigured]) => [
      name,
      {
        configured: isConfigured,
        message: isConfigured
          ? "Connected"
          : "Not configured — add API key to environment",
      },
    ])
  );
}
