import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: Date | string) {
  return new Date(date).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

export function formatRelativeDate(date: Date | string) {
  const now = new Date();
  const then = new Date(date);
  const diffMs = now.getTime() - then.getTime();
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

  if (diffDays === 0) return "Today";
  if (diffDays === 1) return "Yesterday";
  if (diffDays < 7) return `${diffDays} days ago`;
  if (diffDays < 30) return `${Math.floor(diffDays / 7)} weeks ago`;
  return formatDate(date);
}

export function truncate(str: string, length: number) {
  if (str.length <= length) return str;
  return str.substring(0, length) + "…";
}

export function wordCount(text: string) {
  return text.trim().split(/\s+/).filter(Boolean).length;
}

export function estimateReadingTime(text: string) {
  const words = wordCount(text);
  const minutes = Math.ceil(words / 250);
  return `${minutes} min read`;
}

export function getStatusColor(status: string): string {
  const colors: Record<string, string> = {
    DRAFT: "text-zinc-400 bg-zinc-800",
    ANALYZING: "text-amber-400 bg-amber-950",
    SCRIPTING: "text-blue-400 bg-blue-950",
    STORYBOARDING: "text-purple-400 bg-purple-950",
    RENDERING: "text-orange-400 bg-orange-950",
    REVIEWING: "text-cyan-400 bg-cyan-950",
    EXPORTING: "text-indigo-400 bg-indigo-950",
    COMPLETED: "text-emerald-400 bg-emerald-950",
    FAILED: "text-red-400 bg-red-950",
    NEEDS_USER_INPUT: "text-yellow-400 bg-yellow-950",
    QUEUED: "text-zinc-400 bg-zinc-800",
    PROCESSING: "text-amber-400 bg-amber-950",
  };
  return colors[status] ?? "text-zinc-400 bg-zinc-800";
}

export function bytesToSize(bytes: number): string {
  const sizes = ["Bytes", "KB", "MB", "GB"];
  if (bytes === 0) return "0 Bytes";
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / Math.pow(1024, i)).toFixed(2)} ${sizes[i]}`;
}
