import { auth, currentUser } from "@clerk/nextjs/server";
import { prisma } from "@/lib/prisma";
import type { User } from "@prisma/client";

/**
 * Returns the current Clerk auth object. Throws if unauthenticated.
 */
export function requireAuth() {
  const session = auth();
  if (!session.userId) {
    throw new Error("Unauthorized");
  }
  return session;
}

/**
 * Returns the current DB user, creating one if they don't exist yet.
 * Call this in any server action or API route that needs the DB user record.
 */
export async function getCurrentDbUser(): Promise<User> {
  const { userId } = requireAuth();
  const clerkUser = await currentUser();

  if (!clerkUser) {
    throw new Error("Clerk user not found");
  }

  const primaryEmail =
    clerkUser.emailAddresses.find(
      (e) => e.id === clerkUser.primaryEmailAddressId
    )?.emailAddress ?? "";

  const user = await prisma.user.upsert({
    where: { clerkId: userId },
    update: {
      email: primaryEmail,
      name: [clerkUser.firstName, clerkUser.lastName].filter(Boolean).join(" ") || null,
      imageUrl: clerkUser.imageUrl || null,
    },
    create: {
      clerkId: userId,
      email: primaryEmail,
      name: [clerkUser.firstName, clerkUser.lastName].filter(Boolean).join(" ") || null,
      imageUrl: clerkUser.imageUrl || null,
    },
  });

  return user;
}

/**
 * Returns DB user by Clerk ID. Returns null if not found.
 */
export async function getDbUserByClerkId(clerkId: string): Promise<User | null> {
  return prisma.user.findUnique({ where: { clerkId } });
}

/**
 * Checks if the current user is an admin (via ADMIN_CLERK_IDS env var).
 */
export function isAdminUser(clerkId: string): boolean {
  const adminIds = (process.env.ADMIN_CLERK_IDS ?? "").split(",").filter(Boolean);
  return adminIds.includes(clerkId);
}

/**
 * Verifies the current user owns the given project. Throws if not.
 */
export async function requireProjectOwner(projectId: string): Promise<User> {
  const dbUser = await getCurrentDbUser();
  const project = await prisma.project.findUnique({
    where: { id: projectId },
    select: { userId: true },
  });

  if (!project) {
    throw new Error("Project not found");
  }

  if (project.userId !== dbUser.id) {
    throw new Error("Forbidden: you do not own this project");
  }

  return dbUser;
}

/**
 * Deduct credits from a user. Throws if insufficient balance.
 */
export async function deductCredits(
  userId: string,
  amount: number,
  description: string,
  projectId?: string
): Promise<void> {
  await prisma.$transaction(async (tx) => {
    const user = await tx.user.findUnique({ where: { id: userId } });
    if (!user) throw new Error("User not found");
    if (user.credits < amount) throw new Error("Insufficient credits");

    await tx.user.update({
      where: { id: userId },
      data: { credits: { decrement: amount } },
    });

    await tx.creditTransaction.create({
      data: {
        userId,
        amount: -amount,
        type: "DEBIT",
        description,
        projectId: projectId ?? null,
      },
    });
  });
}

/**
 * Compute rights classification from the rights declaration booleans.
 */
export function classifyRights(declaration: {
  ownsStory: boolean;
  isPublicDomain: boolean;
  hasAdaptationRights: boolean;
  involvesRealPeople: boolean;
  hasSensitiveClaims: boolean;
  shouldAnonymize: boolean;
}): "USER_OWNED" | "PUBLIC_DOMAIN" | "LICENSED" | "NEEDS_REVIEW" | "RISKY" | "BLOCKED" {
  if (
    declaration.involvesRealPeople &&
    declaration.hasSensitiveClaims &&
    !declaration.ownsStory
  ) {
    return "BLOCKED";
  }

  if (declaration.hasSensitiveClaims && !declaration.shouldAnonymize) {
    return "RISKY";
  }

  if (declaration.isPublicDomain) return "PUBLIC_DOMAIN";
  if (declaration.ownsStory) return "USER_OWNED";
  if (declaration.hasAdaptationRights) return "LICENSED";

  return "NEEDS_REVIEW";
}
