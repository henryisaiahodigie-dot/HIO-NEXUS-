// ─────────────────────────────────────────────────────────────
// src/types/index.ts
//
// Shared TypeScript types used across the entire app.
// These mirror the Prisma schema so we can use the same
// type definitions in the frontend and backend.
// ─────────────────────────────────────────────────────────────

// Re-export Prisma types so we only import from one place
export type {
  User,
  Project,
  SourceDocument,
  RenderJob,
  Plan,
  ProjectStatus,
  ProjectMode,
  MovieStyle,
  TargetLength,
  SourceFileType,
  JobType,
  JobStatus,
} from "@prisma/client";

// ── API response shapes ───────────────────────────────────────

/** Standard API success response */
export interface ApiSuccess<T = unknown> {
  success: true;
  data: T;
}

/** Standard API error response */
export interface ApiError {
  success: false;
  error: string;
  code?: string;
}

export type ApiResponse<T = unknown> = ApiSuccess<T> | ApiError;

// ── Project with relations (for dashboard display) ────────────
export interface ProjectWithStats {
  id: string;
  title: string;
  description: string | null;
  status: string;
  mode: string;
  movieStyle: string;
  targetLength: string;
  genre: string | null;
  logline: string | null;
  createdAt: Date;
  updatedAt: Date;
  _count: {
    sourceDocuments: number;
    renderJobs: number;
  };
}
