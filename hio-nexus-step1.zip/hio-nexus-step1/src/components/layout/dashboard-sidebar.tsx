// ─────────────────────────────────────────────────────────────
// src/components/layout/dashboard-sidebar.tsx
//
// The left sidebar shown on all dashboard pages.
// Shows navigation links and the user's credit balance.
// ─────────────────────────────────────────────────────────────

import Link from "next/link";
import { UserButton } from "@clerk/nextjs";
import {
  Film,
  LayoutDashboard,
  FolderOpen,
  PlusCircle,
  Settings,
  HelpCircle,
  Sparkles,
} from "lucide-react";

const NAV_LINKS = [
  { href: "/dashboard",        icon: LayoutDashboard, label: "Dashboard" },
  { href: "/projects",         icon: FolderOpen,      label: "My Projects" },
  { href: "/projects/new",     icon: PlusCircle,      label: "New Project" },
];

const BOTTOM_LINKS = [
  { href: "/settings",  icon: Settings,     label: "Settings" },
  { href: "/help",      icon: HelpCircle,   label: "Help & Docs" },
];

export function DashboardSidebar() {
  return (
    <aside className="fixed left-0 top-0 h-screen w-64 bg-nexus-surface border-r border-nexus-border flex flex-col z-40">

      {/* Logo */}
      <div className="px-6 py-5 border-b border-nexus-border">
        <Link href="/" className="flex items-center gap-2.5 group">
          <div className="w-8 h-8 rounded-lg bg-nexus-gold/10 border border-nexus-gold/30 flex items-center justify-center group-hover:bg-nexus-gold/20 transition-colors">
            <Film size={15} className="text-nexus-gold" />
          </div>
          <span className="font-display font-bold text-gradient-gold">
            HIO Nexus
          </span>
        </Link>
      </div>

      {/* Main navigation */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        {NAV_LINKS.map(({ href, icon: Icon, label }) => (
          <Link
            key={href}
            href={href}
            className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-nexus-secondary hover:text-nexus-primary hover:bg-nexus-muted transition-all duration-150 group text-sm font-medium"
          >
            <Icon size={17} className="group-hover:text-nexus-gold transition-colors" />
            {label}
          </Link>
        ))}
      </nav>

      {/* Upgrade prompt (for free users) */}
      <div className="mx-3 mb-4 p-4 rounded-xl bg-nexus-gold/5 border border-nexus-gold/20">
        <div className="flex items-center gap-2 mb-2">
          <Sparkles size={14} className="text-nexus-gold" />
          <span className="text-nexus-gold text-xs font-semibold">3 credits remaining</span>
        </div>
        <p className="text-nexus-tertiary text-xs mb-3 leading-relaxed">
          Free plan. Upgrade to generate more films.
        </p>
        <Link
          href="/pricing"
          className="block w-full text-center py-2 rounded-lg bg-nexus-gold text-nexus-black text-xs font-semibold hover:bg-nexus-gold-light transition-colors"
        >
          Upgrade Plan
        </Link>
      </div>

      {/* Bottom nav + user */}
      <div className="px-3 py-4 border-t border-nexus-border space-y-1">
        {BOTTOM_LINKS.map(({ href, icon: Icon, label }) => (
          <Link
            key={href}
            href={href}
            className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-nexus-secondary hover:text-nexus-primary hover:bg-nexus-muted transition-all duration-150 text-sm"
          >
            <Icon size={16} />
            {label}
          </Link>
        ))}

        {/* Clerk user profile button */}
        <div className="flex items-center gap-3 px-3 pt-3">
          <UserButton
            appearance={{
              elements: {
                avatarBox: "w-8 h-8 ring-1 ring-nexus-border",
              },
            }}
          />
          <span className="text-nexus-secondary text-sm">Account</span>
        </div>
      </div>
    </aside>
  );
}
