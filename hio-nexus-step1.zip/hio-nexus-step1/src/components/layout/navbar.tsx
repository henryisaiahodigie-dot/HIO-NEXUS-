// ─────────────────────────────────────────────────────────────
// src/components/layout/navbar.tsx
//
// The top navigation bar shown on all public pages.
// Uses Clerk hooks to show different buttons depending on
// whether the user is logged in or not.
// ─────────────────────────────────────────────────────────────

import Link from "next/link";
import {
  SignedIn,
  SignedOut,
  UserButton,
} from "@clerk/nextjs";
import { Film } from "lucide-react";

export function Navbar() {
  return (
    <nav className="sticky top-0 z-50 border-b border-nexus-border bg-nexus-deep/80 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">

        {/* ── Logo ─────────────────────────────────────────── */}
        <Link href="/" className="flex items-center gap-2.5 group">
          <div className="w-8 h-8 rounded-lg bg-nexus-gold/10 border border-nexus-gold/30 flex items-center justify-center group-hover:bg-nexus-gold/20 transition-colors">
            <Film size={16} className="text-nexus-gold" />
          </div>
          <span className="font-display font-bold text-lg text-gradient-gold">
            HIO Nexus
          </span>
        </Link>

        {/* ── Navigation links (desktop) ───────────────────── */}
        <div className="hidden md:flex items-center gap-8">
          <Link
            href="#how-it-works"
            className="text-nexus-secondary hover:text-nexus-primary text-sm transition-colors"
          >
            How It Works
          </Link>
          <Link
            href="#pricing"
            className="text-nexus-secondary hover:text-nexus-primary text-sm transition-colors"
          >
            Pricing
          </Link>
        </div>

        {/* ── Auth buttons ─────────────────────────────────── */}
        <div className="flex items-center gap-3">

          {/* Show these buttons when user is NOT logged in */}
          <SignedOut>
            <Link href="/sign-in" className="btn-ghost text-sm">
              Sign In
            </Link>
            <Link href="/sign-up" className="btn-primary text-sm px-4 py-2">
              Get Started
            </Link>
          </SignedOut>

          {/* Show these when user IS logged in */}
          <SignedIn>
            <Link href="/dashboard" className="btn-secondary text-sm px-4 py-2">
              Dashboard
            </Link>
            {/*
              UserButton is Clerk's built-in profile button.
              Clicking it shows: profile, manage account, sign out.
              appearance prop matches our dark theme.
            */}
            <UserButton
              appearance={{
                elements: {
                  avatarBox: "w-9 h-9 ring-1 ring-nexus-gold/30",
                  userButtonPopoverCard:
                    "bg-nexus-card border border-nexus-border shadow-nexus-lg",
                  userButtonPopoverActionButton:
                    "text-nexus-secondary hover:text-nexus-primary hover:bg-nexus-muted",
                  userButtonPopoverActionButtonText: "text-sm",
                  userButtonPopoverFooter: "hidden",
                },
              }}
            />
          </SignedIn>
        </div>
      </div>
    </nav>
  );
}
