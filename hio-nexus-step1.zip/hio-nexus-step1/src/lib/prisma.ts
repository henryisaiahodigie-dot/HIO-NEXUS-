// ─────────────────────────────────────────────────────────────
// src/lib/prisma.ts
//
// This file creates ONE shared database connection for the app.
//
// Why a singleton? Next.js reloads code during development, and
// if we created a new database connection every time, we'd run
// out of connections quickly. This pattern reuses the same one.
// ─────────────────────────────────────────────────────────────

import { PrismaClient } from "@prisma/client";

// Extend the global object so TypeScript doesn't complain
const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    log:
      // In development, log all queries to help with debugging
      process.env.NODE_ENV === "development"
        ? ["query", "error", "warn"]
        : ["error"],
  });

// In development, save the client to the global object so it
// survives hot reloads without creating duplicate connections
if (process.env.NODE_ENV !== "production") {
  globalForPrisma.prisma = prisma;
}
