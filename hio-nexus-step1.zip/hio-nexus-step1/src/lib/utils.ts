// ─────────────────────────────────────────────────────────────
// src/lib/utils.ts
//
// Small helper functions used throughout the app.
// ─────────────────────────────────────────────────────────────

import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

/**
 * cn() — Combine CSS class names intelligently.
 *
 * This merges Tailwind classes without conflicts.
 * Example: cn("px-4 px-6") → "px-6"  (later value wins)
 * Example: cn("text-red-500", isActive && "text-gold") → correct class
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * formatDate() — Turn a Date into a readable string.
 * Example: formatDate(new Date()) → "14 May 2026"
 */
export function formatDate(date: Date | string): string {
  return new Intl.DateTimeFormat("en-GB", {
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(new Date(date));
}

/**
 * formatCurrency() — Format a number as currency.
 * Supports USD, EUR, GBP, NGN and more.
 * Example: formatCurrency(29, "USD") → "$29.00"
 * Example: formatCurrency(29, "NGN") → "₦29.00"
 */
export function formatCurrency(
  amount: number,
  currency: string = "USD"
): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency,
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(amount);
}

/**
 * truncate() — Shorten long text with an ellipsis.
 * Example: truncate("A very long title...", 30) → "A very long titl…"
 */
export function truncate(text: string, length: number): string {
  if (text.length <= length) return text;
  return text.slice(0, length) + "…";
}

/**
 * getInitials() — Get initials from a name for avatar fallback.
 * Example: getInitials("Adaeze Okafor") → "AO"
 */
export function getInitials(name: string): string {
  return name
    .split(" ")
    .map((word) => word[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);
}

/**
 * PROJECT STATUS LABELS
 * Human-readable labels for each project status value.
 */
export const PROJECT_STATUS_LABELS: Record<string, string> = {
  DRAFT:         "Draft",
  ANALYZING:     "Analyzing story…",
  SCRIPTING:     "Writing screenplay…",
  STORYBOARDING: "Building storyboard…",
  RENDERING:     "Generating visuals…",
  REVIEWING:     "Ready for review",
  EXPORTING:     "Preparing export…",
  COMPLETED:     "Completed",
  FAILED:        "Failed — needs attention",
  NEEDS_INPUT:   "Waiting for your input",
};

/**
 * MOVIE STYLE LABELS
 */
export const MOVIE_STYLE_LABELS: Record<string, string> = {
  DOCUMENTARY:         "Documentary",
  CINEMATIC_DRAMA:     "Cinematic Drama",
  HISTORICAL_EPIC:     "Historical Epic",
  FAITH_INSPIRATIONAL: "Faith & Inspirational",
  ROMANCE:             "Romance",
  ACTION:              "Action",
  ANIMATION:           "Animation",
  CHILDREN_FAMILY:     "Children & Family",
  THRILLER:            "Thriller",
  BIOPIC:              "Biopic",
};

/**
 * TARGET LENGTH LABELS
 */
export const TARGET_LENGTH_LABELS: Record<string, string> = {
  TRAILER:        "Trailer (~2 min)",
  SHORT_3MIN:     "Short Film (3 min)",
  PILOT_10MIN:    "Pilot Episode (10 min)",
  EPISODE_30MIN:  "Full Episode (30 min)",
  FEATURE_ROADMAP:"Feature Film Roadmap",
};
