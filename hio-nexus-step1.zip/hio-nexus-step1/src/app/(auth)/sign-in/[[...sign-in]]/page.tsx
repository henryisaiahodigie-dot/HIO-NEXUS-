// ─────────────────────────────────────────────────────────────
// src/app/(auth)/sign-in/[[...sign-in]]/page.tsx
//
// The sign-in page.
//
// The [[...sign-in]] folder name is required by Clerk —
// it tells Clerk to handle all sign-in related routes here
// (e.g. /sign-in, /sign-in/factor-one, /sign-in/sso-callback).
//
// The <SignIn /> component from Clerk renders the full
// sign-in form — email/password AND Google login button.
// You don't need to build the form yourself.
// ─────────────────────────────────────────────────────────────

import { SignIn } from "@clerk/nextjs";
import Link from "next/link";
import { Film } from "lucide-react";

export default function SignInPage() {
  return (
    <div className="min-h-screen bg-nexus-deep flex flex-col items-center justify-center px-6 py-16 section-glow">

      {/* Brand mark */}
      <Link href="/" className="flex items-center gap-2.5 mb-10 group">
        <div className="w-9 h-9 rounded-lg bg-nexus-gold/10 border border-nexus-gold/30 flex items-center justify-center group-hover:bg-nexus-gold/20 transition-colors">
          <Film size={18} className="text-nexus-gold" />
        </div>
        <span className="font-display font-bold text-xl text-gradient-gold">
          HIO Nexus
        </span>
      </Link>

      {/* Clerk sign-in widget — fully handles email + Google */}
      <SignIn
        appearance={{
          // Match HIO Nexus dark theme
          elements: {
            rootBox: "w-full max-w-md",
            card:
              "bg-nexus-card border border-nexus-border shadow-nexus-lg rounded-2xl",
            headerTitle:
              "font-display text-2xl text-nexus-primary",
            headerSubtitle: "text-nexus-secondary text-sm",
            socialButtonsBlockButton:
              "border border-nexus-border bg-nexus-surface text-nexus-primary hover:bg-nexus-muted transition-colors rounded-lg",
            socialButtonsBlockButtonText: "font-medium text-sm",
            dividerLine: "bg-nexus-border",
            dividerText: "text-nexus-tertiary text-xs",
            formFieldLabel: "text-nexus-secondary text-sm font-medium",
            formFieldInput:
              "bg-nexus-surface border border-nexus-border text-nexus-primary rounded-lg focus:border-nexus-gold/50 focus:ring-1 focus:ring-nexus-gold/20",
            formButtonPrimary:
              "bg-nexus-gold text-nexus-black font-semibold hover:bg-nexus-gold-light rounded-lg",
            footerActionLink:
              "text-nexus-gold hover:text-nexus-gold-light font-medium",
            identityPreviewText: "text-nexus-secondary",
            identityPreviewEditButton: "text-nexus-gold",
            alertText: "text-sm",
          },
        }}
      />

      {/* Back link */}
      <Link
        href="/"
        className="mt-6 text-nexus-tertiary hover:text-nexus-secondary text-sm transition-colors"
      >
        ← Back to home
      </Link>
    </div>
  );
}
