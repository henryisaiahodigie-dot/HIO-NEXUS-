// ─────────────────────────────────────────────────────────────
// src/app/api/webhooks/clerk/route.ts
//
// CLERK WEBHOOK HANDLER
//
// When a user signs up or updates their profile in Clerk,
// Clerk sends a notification (webhook) to this URL.
// We listen for it here and save/update the user record
// in our own PostgreSQL database.
//
// This is how our database stays in sync with Clerk's auth system.
//
// You need to configure this URL in your Clerk dashboard:
//   Clerk Dashboard → Webhooks → Add endpoint
//   URL: https://hio-nexus.vercel.app/api/webhooks/clerk
//   Events to send: user.created, user.updated, user.deleted
// ─────────────────────────────────────────────────────────────

import { headers } from "next/headers";
import { NextResponse } from "next/server";
import { Webhook } from "svix"; // Clerk uses svix for webhook verification
import { prisma } from "@/lib/prisma";

// The webhook secret from your Clerk dashboard
// Add CLERK_WEBHOOK_SECRET to your .env.local
const WEBHOOK_SECRET = process.env.CLERK_WEBHOOK_SECRET;

// ── Types for Clerk webhook payloads ─────────────────────────
interface ClerkUserData {
  id: string;
  email_addresses: Array<{ email_address: string; id: string }>;
  primary_email_address_id: string;
  first_name: string | null;
  last_name: string | null;
  image_url: string | null;
}

interface ClerkWebhookEvent {
  type: "user.created" | "user.updated" | "user.deleted";
  data: ClerkUserData;
}

// ── Webhook handler ───────────────────────────────────────────
export async function POST(req: Request) {
  // Make sure the webhook secret is configured
  if (!WEBHOOK_SECRET) {
    console.error("CLERK_WEBHOOK_SECRET not set in environment variables");
    return NextResponse.json(
      { error: "Webhook secret not configured" },
      { status: 500 }
    );
  }

  // Get the Clerk signature headers for verification
  const headerPayload = await headers();
  const svix_id = headerPayload.get("svix-id");
  const svix_timestamp = headerPayload.get("svix-timestamp");
  const svix_signature = headerPayload.get("svix-signature");

  // If headers are missing, this isn't a valid Clerk webhook
  if (!svix_id || !svix_timestamp || !svix_signature) {
    return NextResponse.json(
      { error: "Missing svix headers" },
      { status: 400 }
    );
  }

  // Get the raw request body
  const payload = await req.text();

  // Verify the webhook signature (prevents fake requests)
  const wh = new Webhook(WEBHOOK_SECRET);
  let event: ClerkWebhookEvent;

  try {
    event = wh.verify(payload, {
      "svix-id": svix_id,
      "svix-timestamp": svix_timestamp,
      "svix-signature": svix_signature,
    }) as ClerkWebhookEvent;
  } catch (err) {
    console.error("Webhook verification failed:", err);
    return NextResponse.json(
      { error: "Webhook verification failed" },
      { status: 400 }
    );
  }

  // ── Handle the event ────────────────────────────────────────
  const { type, data } = event;

  // Helper: get primary email from Clerk's email array
  const getPrimaryEmail = (userData: ClerkUserData): string => {
    const primary = userData.email_addresses.find(
      (e) => e.id === userData.primary_email_address_id
    );
    return primary?.email_address ?? userData.email_addresses[0]?.email_address ?? "";
  };

  try {
    if (type === "user.created") {
      // New user signed up — create their record in our database
      await prisma.user.create({
        data: {
          id: data.id, // Use Clerk's user ID as our primary key
          email: getPrimaryEmail(data),
          name: [data.first_name, data.last_name].filter(Boolean).join(" ") || null,
          imageUrl: data.image_url,
          plan: "FREE",
          credits: 3, // Every new user gets 3 free credits
          currency: "USD",
        },
      });
      console.log(`✅ New user created: ${data.id}`);
    }

    else if (type === "user.updated") {
      // User updated their profile — sync changes to our database
      await prisma.user.upsert({
        where: { id: data.id },
        update: {
          email: getPrimaryEmail(data),
          name: [data.first_name, data.last_name].filter(Boolean).join(" ") || null,
          imageUrl: data.image_url,
        },
        create: {
          id: data.id,
          email: getPrimaryEmail(data),
          name: [data.first_name, data.last_name].filter(Boolean).join(" ") || null,
          imageUrl: data.image_url,
          plan: "FREE",
          credits: 3,
          currency: "USD",
        },
      });
      console.log(`✅ User updated: ${data.id}`);
    }

    else if (type === "user.deleted") {
      // User deleted their account — remove from our database
      // Cascade delete removes all their projects, documents, and jobs too
      await prisma.user.delete({
        where: { id: data.id },
      });
      console.log(`✅ User deleted: ${data.id}`);
    }

    return NextResponse.json({ success: true }, { status: 200 });

  } catch (error) {
    console.error("Error processing webhook:", error);
    return NextResponse.json(
      { error: "Database operation failed" },
      { status: 500 }
    );
  }
}
