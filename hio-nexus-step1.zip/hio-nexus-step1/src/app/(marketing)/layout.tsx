// src/app/(marketing)/layout.tsx
// Layout for public-facing pages (homepage, pricing, about)

import { Navbar } from "@/components/layout/navbar";

export default function MarketingLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1">{children}</main>
      <footer className="border-t border-nexus-border py-8 mt-16">
        <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-nexus-tertiary text-sm">
            © 2026 HIO Nexus. Your story deserves a screen.
          </p>
          <div className="flex gap-6">
            <a href="#" className="text-nexus-tertiary hover:text-nexus-secondary text-sm transition-colors">Privacy</a>
            <a href="#" className="text-nexus-tertiary hover:text-nexus-secondary text-sm transition-colors">Terms</a>
            <a href="#" className="text-nexus-tertiary hover:text-nexus-secondary text-sm transition-colors">Contact</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
