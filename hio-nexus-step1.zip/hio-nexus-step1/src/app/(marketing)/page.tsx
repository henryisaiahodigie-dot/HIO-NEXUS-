// ─────────────────────────────────────────────────────────────
// src/app/(marketing)/page.tsx
// THE HOMEPAGE — the first thing visitors see
// ─────────────────────────────────────────────────────────────

import Link from "next/link";
import {
  BookOpen,
  Film,
  Users,
  Layers,
  ArrowRight,
  ChevronRight,
  Sparkles,
  Star,
} from "lucide-react";

// ── Who HIO Nexus is built for ────────────────────────────────
const AUDIENCES = [
  {
    icon: BookOpen,
    title: "Authors & Novelists",
    description:
      "Turn your novel or manuscript into a cinematic pilot. See your world come to life on screen.",
  },
  {
    icon: Users,
    title: "Families & Memoir Writers",
    description:
      "Preserve your family's story as an emotional film. A legacy that lasts for generations.",
  },
  {
    icon: Film,
    title: "Content Creators",
    description:
      "Transform scripts and ideas into episodic cinematic content. Build your story universe.",
  },
  {
    icon: Layers,
    title: "Publishers & Studios",
    description:
      "Rapidly test book-to-film adaptation potential. Produce pilots before greenlighting.",
  },
];

// ── The 10-step pipeline shown on the homepage ────────────────
const PIPELINE_STEPS = [
  { step: "01", label: "Upload your story" },
  { step: "02", label: "Story analysis" },
  { step: "03", label: "Screenplay" },
  { step: "04", label: "Character bible" },
  { step: "05", label: "Storyboard" },
  { step: "06", label: "Scene plan" },
  { step: "07", label: "Voice & music" },
  { step: "08", label: "Cinematic generation" },
  { step: "09", label: "Review & edit" },
  { step: "10", label: "Export your film" },
];

// ── Competitor comparison ─────────────────────────────────────
const COMPARISON = [
  { tool: "Midjourney",          does: "Creates images" },
  { tool: "Kling / Runway / Veo", does: "Creates short clips" },
  { tool: "HIO Nexus",           does: "Produces the full movie pipeline", highlight: true },
];

export default function HomePage() {
  return (
    <div className="overflow-hidden">

      {/* ── HERO ─────────────────────────────────────────────── */}
      <section className="relative section-glow min-h-[90vh] flex items-center justify-center px-6 py-24">
        {/* Background grid pattern */}
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: `linear-gradient(#c9a84c 1px, transparent 1px),
                              linear-gradient(90deg, #c9a84c 1px, transparent 1px)`,
            backgroundSize: "60px 60px",
          }}
        />

        <div className="relative max-w-5xl mx-auto text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-nexus-gold/30 bg-nexus-gold/5 mb-8">
            <Sparkles size={14} className="text-nexus-gold" />
            <span className="text-nexus-gold text-xs font-medium tracking-widest uppercase">
              AI Film Studio
            </span>
          </div>

          {/* Main headline */}
          <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl font-bold leading-tight mb-6 text-balance">
            Your story{" "}
            <span className="text-gradient-gold">deserves</span>
            <br />a screen.
          </h1>

          {/* Sub-headline */}
          <p className="text-nexus-secondary text-lg sm:text-xl max-w-2xl mx-auto mb-10 leading-relaxed">
            Upload your biography, manuscript, novel, or life story.
            HIO Nexus turns it into a fully produced cinematic film —
            screenplay, characters, storyboard, voices, and video.
          </p>

          {/* CTA buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/sign-up" className="btn-primary text-base px-8 py-3">
              Start Your Film Free
              <ArrowRight size={18} />
            </Link>
            <Link href="#how-it-works" className="btn-secondary text-base px-8 py-3">
              See How It Works
            </Link>
          </div>

          {/* Social proof */}
          <p className="mt-8 text-nexus-tertiary text-sm">
            No credit card required · Free plan includes 3 story analyses
          </p>
        </div>
      </section>

      {/* ── POSITIONING vs COMPETITORS ───────────────────────── */}
      <section className="py-16 px-6">
        <div className="max-w-3xl mx-auto">
          <div className="card p-8">
            <p className="text-nexus-secondary text-sm uppercase tracking-widest mb-6 text-center">
              How we're different
            </p>
            <div className="space-y-3">
              {COMPARISON.map(({ tool, does, highlight }) => (
                <div
                  key={tool}
                  className={`flex items-center justify-between p-4 rounded-lg transition-all ${
                    highlight
                      ? "bg-nexus-gold/10 border border-nexus-gold/30"
                      : "bg-nexus-surface"
                  }`}
                >
                  <span
                    className={`font-medium ${
                      highlight ? "text-nexus-gold" : "text-nexus-secondary"
                    }`}
                  >
                    {tool}
                  </span>
                  <span className="flex items-center gap-2 text-sm text-nexus-secondary">
                    {highlight && <Star size={14} className="text-nexus-gold fill-nexus-gold" />}
                    <span className={highlight ? "text-nexus-primary font-semibold" : ""}>
                      {does}
                    </span>
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── PIPELINE (How It Works) ───────────────────────────── */}
      <section id="how-it-works" className="py-24 px-6">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <p className="text-nexus-gold text-sm uppercase tracking-widest mb-3">
              The Full Pipeline
            </p>
            <h2 className="font-display text-4xl font-bold mb-4">
              From manuscript to movie
            </h2>
            <p className="text-nexus-secondary max-w-xl mx-auto">
              Every step of film production, handled by AI. You stay in creative
              control at every stage.
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            {PIPELINE_STEPS.map(({ step, label }, index) => (
              <div
                key={step}
                className="card p-4 text-center group hover:border-nexus-gold/30 transition-all duration-300"
                style={{ animationDelay: `${index * 60}ms` }}
              >
                <div className="text-nexus-gold/50 text-xs font-mono mb-2 group-hover:text-nexus-gold transition-colors">
                  {step}
                </div>
                <div className="text-nexus-primary text-sm font-medium">
                  {label}
                </div>
              </div>
            ))}
          </div>

          {/* Arrow connecting the steps conceptually */}
          <div className="mt-8 text-center">
            <p className="text-nexus-tertiary text-sm">
              Story, screenplay, scenes, sound, and cinema — in one pipeline.
            </p>
          </div>
        </div>
      </section>

      {/* ── AUDIENCES ─────────────────────────────────────────── */}
      <section className="py-24 px-6 bg-nexus-surface/50">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <p className="text-nexus-gold text-sm uppercase tracking-widest mb-3">
              Built for storytellers
            </p>
            <h2 className="font-display text-4xl font-bold">
              Who uses HIO Nexus?
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {AUDIENCES.map(({ icon: Icon, title, description }) => (
              <div key={title} className="card-hover p-6 group">
                <div className="w-10 h-10 rounded-lg bg-nexus-gold/10 flex items-center justify-center mb-4 group-hover:bg-nexus-gold/20 transition-colors">
                  <Icon size={20} className="text-nexus-gold" />
                </div>
                <h3 className="font-semibold text-nexus-primary mb-2">{title}</h3>
                <p className="text-nexus-secondary text-sm leading-relaxed">
                  {description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── TWO MODES ─────────────────────────────────────────── */}
      <section className="py-24 px-6">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <p className="text-nexus-gold text-sm uppercase tracking-widest mb-3">
              Two ways to create
            </p>
            <h2 className="font-display text-4xl font-bold">
              Simple or Studio
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Simple Mode */}
            <div className="card p-8 border-nexus-teal/20">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-nexus-teal/10 border border-nexus-teal/30 mb-6">
                <span className="text-nexus-teal text-xs font-medium">Simple Mode</span>
              </div>
              <h3 className="font-display text-2xl font-bold mb-3">
                One click. One film.
              </h3>
              <p className="text-nexus-secondary mb-6 leading-relaxed">
                Upload your story, choose your style and length, click Create.
                HIO Nexus handles everything — screenplay, characters, storyboard,
                and animatic proof cut.
              </p>
              <p className="text-nexus-tertiary text-sm">
                Perfect for: authors, families, first-time creators
              </p>
            </div>

            {/* Studio Mode */}
            <div className="card p-8 border-nexus-gold/20">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-nexus-gold/10 border border-nexus-gold/30 mb-6">
                <span className="text-nexus-gold text-xs font-medium">Studio Mode</span>
              </div>
              <h3 className="font-display text-2xl font-bold mb-3">
                Full production control.
              </h3>
              <p className="text-nexus-secondary mb-6 leading-relaxed">
                Edit the screenplay. Approve characters. Regenerate scenes.
                Choose voices and music. Manage the full timeline and export
                any component at any stage.
              </p>
              <p className="text-nexus-tertiary text-sm">
                Perfect for: production teams, publishers, studios
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ── HONEST MVP STATEMENT ──────────────────────────────── */}
      <section className="py-16 px-6">
        <div className="max-w-3xl mx-auto">
          <div className="card p-8 border-nexus-muted text-center">
            <p className="text-nexus-gold text-xs uppercase tracking-widest mb-4">
              What HIO Nexus delivers today
            </p>
            <h3 className="font-display text-2xl font-bold mb-4">
              Build the pilot first. Scale to the full film.
            </h3>
            <p className="text-nexus-secondary leading-relaxed mb-6">
              The MVP delivers full story analysis, screenplay, character bible,
              storyboard, and an MP4 animatic proof cut — everything you need to
              validate and develop your story. Final cinematic rendering requires
              a connected render provider, coming in Phase 2.
            </p>
            <p className="text-nexus-tertiary text-sm">
              We never call a draft a finished film. Every step is clearly labelled.
            </p>
          </div>
        </div>
      </section>

      {/* ── FINAL CTA ─────────────────────────────────────────── */}
      <section className="py-24 px-6 section-glow">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="font-display text-5xl font-bold mb-6">
            Your story is{" "}
            <span className="text-gradient-gold">waiting</span>.
          </h2>
          <p className="text-nexus-secondary text-lg mb-10">
            Not just clips. Coherent cinematic storytelling.
          </p>
          <Link href="/sign-up" className="btn-primary text-base px-10 py-4">
            Start for Free
            <ChevronRight size={18} />
          </Link>
        </div>
      </section>
    </div>
  );
}
