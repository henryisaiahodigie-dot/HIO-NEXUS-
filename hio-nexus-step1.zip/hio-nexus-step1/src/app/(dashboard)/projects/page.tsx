// src/app/(dashboard)/projects/page.tsx
// Projects list — will be populated with real data in Step 2

import Link from "next/link";
import { PlusCircle, Film } from "lucide-react";

export default function ProjectsPage() {
  return (
    <div className="p-8 max-w-6xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="font-display text-3xl font-bold mb-1">My Projects</h1>
          <p className="text-nexus-secondary text-sm">
            Each project is one story being turned into a film.
          </p>
        </div>
        <Link href="/projects/new" className="btn-primary">
          <PlusCircle size={18} />
          New Project
        </Link>
      </div>

      {/* Empty state */}
      <div className="card p-16 text-center">
        <div className="w-14 h-14 rounded-xl bg-nexus-gold/10 border border-nexus-gold/20 flex items-center justify-center mx-auto mb-5">
          <Film size={24} className="text-nexus-gold" />
        </div>
        <h2 className="font-semibold text-nexus-primary text-lg mb-2">No projects yet</h2>
        <p className="text-nexus-secondary text-sm mb-6">
          Start your first project to begin the production pipeline.
        </p>
        <Link href="/projects/new" className="btn-primary">
          <PlusCircle size={16} />
          Create First Project
        </Link>
      </div>
    </div>
  );
}
