// src/app/(dashboard)/projects/new/page.tsx
// New project creation — the form logic comes in Step 2.
// Step 1 just shows the shell so the app navigates correctly.

import Link from "next/link";
import { ArrowLeft, Film, BookOpen, FileText, Mic } from "lucide-react";

const STORY_TYPES = [
  { icon: BookOpen, label: "Novel or Manuscript", desc: "Fiction or non-fiction book" },
  { icon: Film,     label: "Biography or Memoir", desc: "Real life story" },
  { icon: FileText, label: "Script or Idea",       desc: "Existing script or concept" },
  { icon: Mic,      label: "Interview Transcript", desc: "Spoken story, transcribed" },
];

export default function NewProjectPage() {
  return (
    <div className="p-8 max-w-3xl mx-auto">

      {/* Back */}
      <Link href="/dashboard" className="flex items-center gap-2 text-nexus-secondary hover:text-nexus-primary text-sm mb-8 transition-colors w-fit">
        <ArrowLeft size={16} />
        Back to Dashboard
      </Link>

      <div className="mb-10">
        <h1 className="font-display text-3xl font-bold mb-2">Start a New Project</h1>
        <p className="text-nexus-secondary">
          Every great film starts with a story. Tell us about yours.
        </p>
      </div>

      {/* Step 1 placeholder — form comes in Step 2 */}
      <div className="card p-8">
        <p className="text-nexus-gold text-xs uppercase tracking-widest mb-6">
          What kind of story are you bringing?
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-8">
          {STORY_TYPES.map(({ icon: Icon, label, desc }) => (
            <button
              key={label}
              className="card-hover p-5 text-left group cursor-pointer border-transparent hover:border-nexus-gold/30"
            >
              <Icon size={20} className="text-nexus-gold mb-3" />
              <p className="font-medium text-nexus-primary text-sm mb-1">{label}</p>
              <p className="text-nexus-tertiary text-xs">{desc}</p>
            </button>
          ))}
        </div>

        <div className="divider mb-6" />

        <p className="text-nexus-tertiary text-sm text-center">
          Full project creation form coming in Step 2.
          <br />
          Database, file upload, and AI pipeline will be connected next.
        </p>
      </div>
    </div>
  );
}
