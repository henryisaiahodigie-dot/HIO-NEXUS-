// ─────────────────────────────────────────────────────────────
// src/app/(dashboard)/dashboard/page.tsx
//
// The main dashboard — shown after login.
// In Step 1 this is a shell. Step 2 will wire in real data.
// ─────────────────────────────────────────────────────────────

import { currentUser } from "@clerk/nextjs/server";
import { redirect } from "next/navigation";
import Link from "next/link";
import {
  PlusCircle,
  Film,
  Clock,
  CheckCircle2,
  Sparkles,
  ArrowRight,
} from "lucide-react";

// ── Placeholder stats (will be real data in Step 2) ──────────
const PLACEHOLDER_STATS = [
  { label: "Active Projects",   value: "0",  icon: Film },
  { label: "Credits Remaining", value: "3",  icon: Sparkles },
  { label: "In Progress",       value: "0",  icon: Clock },
  { label: "Completed",         value: "0",  icon: CheckCircle2 },
];

export default async function DashboardPage() {
  // Get the current user from Clerk (server-side)
  const user = await currentUser();

  // If somehow not logged in, redirect to sign-in
  if (!user) redirect("/sign-in");

  // Get the user's first name for the greeting
  const firstName = user.firstName ?? "there";

  return (
    <div className="p-8 max-w-6xl mx-auto">

      {/* ── Header ─────────────────────────────────────────── */}
      <div className="flex items-start justify-between mb-10">
        <div>
          <h1 className="font-display text-3xl font-bold mb-1">
            Welcome back, {firstName}
          </h1>
          <p className="text-nexus-secondary">
            Your film studio is ready. What story are we telling today?
          </p>
        </div>

        <Link href="/projects/new" className="btn-primary">
          <PlusCircle size={18} />
          New Project
        </Link>
      </div>

      {/* ── Stats row ──────────────────────────────────────── */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
        {PLACEHOLDER_STATS.map(({ label, value, icon: Icon }) => (
          <div key={label} className="card p-5">
            <div className="flex items-center justify-between mb-3">
              <span className="text-nexus-tertiary text-sm">{label}</span>
              <Icon size={16} className="text-nexus-gold/50" />
            </div>
            <p className="font-display text-3xl font-bold text-nexus-primary">
              {value}
            </p>
          </div>
        ))}
      </div>

      {/* ── Empty state (no projects yet) ──────────────────── */}
      <div className="card p-16 text-center">
        {/* Film reel icon */}
        <div className="w-16 h-16 rounded-2xl bg-nexus-gold/10 border border-nexus-gold/20 flex items-center justify-center mx-auto mb-6">
          <Film size={28} className="text-nexus-gold" />
        </div>

        <h2 className="font-display text-2xl font-bold mb-3">
          Your first film starts here
        </h2>
        <p className="text-nexus-secondary max-w-md mx-auto mb-8 leading-relaxed">
          Upload a biography, manuscript, novel, or paste your story.
          HIO Nexus will analyse it, write the screenplay, build characters,
          and generate your storyboard.
        </p>

        <Link href="/projects/new" className="btn-primary px-8 py-3 text-base">
          Start My First Project
          <ArrowRight size={18} />
        </Link>

        {/* What you get */}
        <div className="mt-10 grid grid-cols-1 sm:grid-cols-3 gap-4 text-left">
          {[
            { step: "01", label: "Upload your story", desc: "PDF, Word doc, or paste text" },
            { step: "02", label: "AI produces your screenplay", desc: "Logline, treatment, full script" },
            { step: "03", label: "Get your storyboard & animatic", desc: "Visual proof cut ready to share" },
          ].map(({ step, label, desc }) => (
            <div key={step} className="bg-nexus-surface rounded-xl p-4 border border-nexus-border">
              <div className="text-nexus-gold/50 text-xs font-mono mb-2">{step}</div>
              <p className="text-nexus-primary text-sm font-medium mb-1">{label}</p>
              <p className="text-nexus-tertiary text-xs">{desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* ── Honest capability statement ────────────────────── */}
      <div className="mt-6 p-4 rounded-xl border border-nexus-border bg-nexus-surface/50 flex items-start gap-3">
        <Sparkles size={16} className="text-nexus-gold mt-0.5 shrink-0" />
        <p className="text-nexus-tertiary text-sm leading-relaxed">
          <strong className="text-nexus-secondary">MVP — Phase 1:</strong>{" "}
          Story analysis, screenplay, character bible, storyboard, and MP4 animatic proof cut.
          Final cinematic rendering will be available when a render provider is connected (Phase 2).
        </p>
      </div>
    </div>
  );
}
