// ─────────────────────────────────────────────────────────────
// src/app/(dashboard)/layout.tsx
//
// Layout for all dashboard pages (project list, project detail, etc.)
// Every dashboard page gets the sidebar automatically.
// ─────────────────────────────────────────────────────────────

import { DashboardSidebar } from "@/components/layout/dashboard-sidebar";

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen flex bg-nexus-deep">

      {/* Sidebar — fixed on the left */}
      <DashboardSidebar />

      {/* Main content area */}
      <main className="flex-1 ml-64 min-h-screen">
        {children}
      </main>
    </div>
  );
}
