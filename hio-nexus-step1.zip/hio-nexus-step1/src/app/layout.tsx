// ─────────────────────────────────────────────────────────────
// src/app/layout.tsx
//
// The ROOT LAYOUT — wraps every single page in the app.
// This is where we:
//   1. Set up fonts
//   2. Wrap the app with ClerkProvider (enables auth everywhere)
//   3. Set the base HTML structure and global styles
// ─────────────────────────────────────────────────────────────

import type { Metadata } from "next";
import { Inter, Playfair_Display } from "next/font/google";
import { ClerkProvider } from "@clerk/nextjs";
import "./globals.css";

// ── Fonts ────────────────────────────────────────────────────
// Inter: clean, modern sans-serif for body text and UI
const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

// Playfair Display: elegant serif for cinematic headings
const playfair = Playfair_Display({
  subsets: ["latin"],
  variable: "--font-playfair",
  display: "swap",
});

// ── Page Metadata ─────────────────────────────────────────────
// This appears in browser tabs and search engine results
export const metadata: Metadata = {
  title: {
    default: "HIO Nexus — From Manuscript to Movie",
    template: "%s | HIO Nexus",
  },
  description:
    "The AI film studio that turns biographies, manuscripts, novels, and life stories into fully watchable cinematic films.",
  keywords: ["AI film", "story to movie", "manuscript", "biography", "cinematic AI"],
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://hio-nexus.vercel.app",
    siteName: "HIO Nexus",
    title: "HIO Nexus — From Manuscript to Movie",
    description: "Your story deserves a screen.",
  },
};

// ── Root Layout Component ─────────────────────────────────────
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    // ClerkProvider MUST wrap the entire app for auth to work everywhere
    <ClerkProvider>
      <html
        lang="en"
        // Attach CSS font variables so Tailwind can use them
        className={`${inter.variable} ${playfair.variable}`}
      >
        <body
          // Base dark background — the deepest black in our palette
          className="bg-nexus-deep text-nexus-primary antialiased"
        >
          {children}
        </body>
      </html>
    </ClerkProvider>
  );
}
