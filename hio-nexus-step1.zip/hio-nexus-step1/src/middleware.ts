// ─────────────────────────────────────────────────────────────
// src/middleware.ts
//
// This file runs on EVERY page request before the page loads.
// It checks whether the user is logged in.
//
// PUBLIC routes: anyone can visit (homepage, sign-in, sign-up)
// PROTECTED routes: only logged-in users can visit (dashboard)
//
// If a logged-out user tries to visit /dashboard, Clerk
// automatically redirects them to the sign-in page.
// ─────────────────────────────────────────────────────────────

import { clerkMiddleware, createRouteMatcher } from "@clerk/nextjs/server";

// Define which routes require the user to be logged in
const isProtectedRoute = createRouteMatcher([
  "/dashboard(.*)",   // /dashboard and all sub-pages
  "/projects(.*)",    // /projects and all sub-pages
  "/api/projects(.*)", // project API endpoints
]);

export default clerkMiddleware(async (auth, req) => {
  // If the route is protected and user is not logged in,
  // Clerk redirects them to sign-in automatically
  if (isProtectedRoute(req)) {
    await auth.protect();
  }
});

// Tell Next.js which paths this middleware should run on.
// This excludes static files, images, and Next.js internals.
export const config = {
  matcher: [
    "/((?!_next|[^?]*\\.(?:html?|css|js(?!on)|jpe?g|webp|png|gif|svg|ttf|woff2?|ico|csv|docx?|xlsx?|zip|webmanifest)).*)",
    "/(api|trpc)(.*)",
  ],
};
