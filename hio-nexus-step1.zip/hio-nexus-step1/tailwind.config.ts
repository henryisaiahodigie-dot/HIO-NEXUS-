import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        // ── HIO Nexus cinematic dark palette ──────────────────────
        nexus: {
          // Backgrounds (darkest → lightest surface)
          black:   "#050507",
          deep:    "#0a0a0f",
          surface: "#111118",
          card:    "#16161f",
          border:  "#1f1f2e",
          muted:   "#2a2a3a",
          // Gold accent — premium, cinematic
          gold:        "#c9a84c",
          "gold-light":"#e8c96a",
          "gold-dim":  "#8a6f2f",
          // Teal accent — technology, AI
          teal:        "#00c4a0",
          "teal-dim":  "#007a63",
          // Text hierarchy
          primary:   "#f0ede8",
          secondary: "#9d9aaa",
          tertiary:  "#5a5870",
        },
      },
      // Cinematic font pairing
      fontFamily: {
        sans:    ["var(--font-inter)", "system-ui", "sans-serif"],
        display: ["var(--font-playfair)", "Georgia", "serif"],
      },
      backgroundImage: {
        // Subtle gold glow — used on hero section
        "nexus-glow":
          "radial-gradient(ellipse 80% 50% at 50% -10%, rgba(201,168,76,0.15), transparent)",
        // Teal glow — used on AI feature sections
        "nexus-glow-teal":
          "radial-gradient(ellipse 60% 40% at 50% 0%, rgba(0,196,160,0.12), transparent)",
        // Subtle noise texture for depth
        "nexus-texture":
          "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.03'/%3E%3C/svg%3E\")",
      },
      animation: {
        "fade-in":    "fadeIn 0.6s ease forwards",
        "slide-up":   "slideUp 0.5s ease forwards",
        "shimmer":    "shimmer 2.5s linear infinite",
        "pulse-gold": "pulseGold 3s ease-in-out infinite",
      },
      keyframes: {
        fadeIn:    { from: { opacity: "0" },                         to: { opacity: "1" } },
        slideUp:   { from: { opacity: "0", transform: "translateY(20px)" }, to: { opacity: "1", transform: "translateY(0)" } },
        shimmer:   { "0%": { backgroundPosition: "-200% 0" },        "100%": { backgroundPosition: "200% 0" } },
        pulseGold: { "0%,100%": { opacity: "0.5" },                  "50%": { opacity: "1" } },
      },
      boxShadow: {
        "nexus":      "0 0 40px rgba(201,168,76,0.08)",
        "nexus-lg":   "0 0 80px rgba(201,168,76,0.14)",
        "card":       "0 1px 3px rgba(0,0,0,0.5), 0 0 0 1px rgba(31,31,46,0.8)",
        "card-hover": "0 4px 24px rgba(0,0,0,0.6), 0 0 0 1px rgba(201,168,76,0.2)",
        "gold-sm":    "0 0 16px rgba(201,168,76,0.3)",
      },
    },
  },
  plugins: [],
};

export default config;
