import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  images: {
    remotePatterns: [
      // Google profile pictures (for Google login)
      { protocol: "https", hostname: "lh3.googleusercontent.com" },
      // Clerk-hosted images
      { protocol: "https", hostname: "img.clerk.com" },
      // Future: your own asset storage
      { protocol: "https", hostname: "*.r2.cloudflarestorage.com" },
    ],
  },
};

export default nextConfig;
