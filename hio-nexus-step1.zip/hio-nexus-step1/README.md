# HIO Nexus — Deployment Guide

> Written for the founder. No developer experience required.
> Follow every step in order. Don't skip steps.

---

## What you're setting up in Step 1

- A Next.js web app (your film studio in the browser)
- A PostgreSQL database on Neon.tech (where your data lives)
- Clerk authentication (email + Google login)
- Deployed to your existing Vercel project

---

## Before you start — what you need

- [ ] Your Vercel account at vercel.com (you have this)
- [ ] Your GitHub account (you have this)
- [ ] Node.js installed on your computer
  - Check: open Terminal and type `node --version`
  - If you see `v18.x` or higher, you're good
  - If not: download from https://nodejs.org (choose "LTS" version)

---

## Part A — Set up your database (Neon.tech)

**Why Neon?** It's a free PostgreSQL database in the cloud. No server to manage.

1. Go to https://neon.tech
2. Click **Sign Up** (you can use your Google account)
3. Click **New Project**
4. Name it: `hio-nexus`
5. Choose region: **US East** (or closest to you)
6. Click **Create Project**
7. You'll see a **Connection String** — it looks like:
   ```
   postgresql://alex:password123@ep-cool-morning-123456.us-east-2.aws.neon.tech/neondb?sslmode=require
   ```
8. **Copy that entire string** — you'll need it in Part C

---

## Part B — Set up Clerk (authentication)

**Why Clerk?** Handles login so you don't have to build it yourself.

1. Go to https://clerk.com
2. Click **Sign Up**
3. Click **Create Application**
4. Application name: `HIO Nexus`
5. Enable these login methods:
   - ✅ Email address
   - ✅ Google
6. Click **Create Application**

**Get your API keys:**
7. In the Clerk dashboard, click **API Keys** in the left sidebar
8. You'll see:
   - **Publishable key** (starts with `pk_test_`)
   - **Secret key** (starts with `sk_test_`)
9. Copy both — you'll need them in Part C

**Enable Google login:**
10. In Clerk → **Social Connections** → Click **Google**
11. Follow Clerk's guide to connect Google OAuth
    (Clerk has a simple step-by-step — takes ~5 minutes)

**Set up the webhook (syncs Clerk users to your database):**
12. In Clerk → **Webhooks** → **Add Endpoint**
13. URL: `https://hio-nexus.vercel.app/api/webhooks/clerk`
14. Select events: `user.created`, `user.updated`, `user.deleted`
15. Click **Create**
16. Copy the **Signing Secret** (starts with `whsec_`)

---

## Part C — Set up the project on your computer

Open **Terminal** (Mac) or **Command Prompt** (Windows).

### 1. Get the code

```bash
# Go to your desktop (or wherever you want the project)
cd ~/Desktop

# Clone from GitHub (replace YOUR-USERNAME with your GitHub username)
git clone https://github.com/YOUR-USERNAME/hio-nexus.git

# Go into the project folder
cd hio-nexus
```

### 2. Install dependencies

```bash
npm install
```

This downloads all the code libraries. Takes 1-3 minutes. Wait for it to finish.

### 3. Create your environment file

```bash
# Copy the example file
cp .env.example .env.local
```

Now open `.env.local` in any text editor (Notepad, TextEdit, VS Code).

Fill in these values:

```
DATABASE_URL="paste your Neon connection string here"

NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY="paste your Clerk publishable key here"
CLERK_SECRET_KEY="paste your Clerk secret key here"

NEXT_PUBLIC_CLERK_SIGN_IN_URL="/sign-in"
NEXT_PUBLIC_CLERK_SIGN_UP_URL="/sign-up"
NEXT_PUBLIC_CLERK_AFTER_SIGN_IN_URL="/dashboard"
NEXT_PUBLIC_CLERK_AFTER_SIGN_UP_URL="/dashboard"

CLERK_WEBHOOK_SECRET="paste your Clerk webhook signing secret here"

NEXT_PUBLIC_APP_URL="http://localhost:3000"
```

Save the file.

### 4. Create your database tables

```bash
npm run db:push
```

This creates all the tables in your Neon database based on the schema.
You should see: `✅ Your database is now in sync with your Prisma schema.`

### 5. Generate the database client

```bash
npm run db:generate
```

### 6. Run the app locally

```bash
npm run dev
```

Open your browser and go to: **http://localhost:3000**

You should see the HIO Nexus homepage. 🎉

---

## Part D — Deploy to Vercel

### 1. Push code to GitHub

```bash
# From inside your project folder:
git add .
git commit -m "Step 1: Foundation — auth, database, homepage"
git push origin main
```

### 2. Connect to Vercel

1. Go to https://vercel.com and log in
2. Click **Add New Project**
3. Import your `hio-nexus` GitHub repository
4. Vercel will detect it's a Next.js project automatically

### 3. Add environment variables in Vercel

Before clicking Deploy, click **Environment Variables** and add:

| Name | Value |
|------|-------|
| `DATABASE_URL` | Your Neon connection string |
| `NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY` | Your Clerk publishable key |
| `CLERK_SECRET_KEY` | Your Clerk secret key |
| `NEXT_PUBLIC_CLERK_SIGN_IN_URL` | `/sign-in` |
| `NEXT_PUBLIC_CLERK_SIGN_UP_URL` | `/sign-up` |
| `NEXT_PUBLIC_CLERK_AFTER_SIGN_IN_URL` | `/dashboard` |
| `NEXT_PUBLIC_CLERK_AFTER_SIGN_UP_URL` | `/dashboard` |
| `CLERK_WEBHOOK_SECRET` | Your Clerk webhook secret |
| `NEXT_PUBLIC_APP_URL` | `https://hio-nexus.vercel.app` |

### 4. Deploy

Click **Deploy**. Vercel builds and deploys in ~2 minutes.

Your app is live at: **https://hio-nexus.vercel.app**

---

## Verify everything works

- [ ] Homepage loads at https://hio-nexus.vercel.app
- [ ] Sign Up page works — try creating an account
- [ ] Google login button appears and works
- [ ] After sign in, you land on the dashboard
- [ ] Dashboard shows your name in the greeting

---

## Troubleshooting

**"Prisma client not generated" error**
```bash
npm run db:generate
npm run dev
```

**"Invalid DATABASE_URL" error**
- Check your `.env.local` — make sure no quotes are missing
- Make sure the Neon database is active (Neon pauses after inactivity — just click Resume in the Neon dashboard)

**"Clerk publishable key not found"**
- Make sure your `.env.local` has `NEXT_PUBLIC_` prefix on the publishable key
- Restart the dev server: press Ctrl+C then `npm run dev` again

**Build fails on Vercel**
- Check that all environment variables are added in the Vercel dashboard
- Check the Vercel deployment logs for the specific error

---

## What's next — Step 2

Once you confirm Step 1 is working, Step 2 will add:

- Story upload (PDF, Word, paste text)
- Claude AI analysis of your story
- Project creation form with rights declaration
- Your first real AI pipeline call

---

*HIO Nexus — Your story deserves a screen.*
